-- Runno MVP V1 schema for Supabase
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  email text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.spaces (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  company text not null,
  unit text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  space_id uuid not null references public.spaces (id) on delete cascade,
  title text not null,
  description text,
  date date not null,
  time time not null,
  category text not null check (category in ('Administrativo', 'Financeiro', 'RH', 'Compras', 'Pessoal')),
  color text not null default '#8B5CF6',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  space_id uuid not null references public.spaces (id) on delete cascade,
  title text not null,
  description text,
  category text not null check (category in ('Administrativo', 'Financeiro', 'RH', 'Compras', 'Pessoal')),
  priority text not null check (priority in ('Critica', 'Importante', 'Normal')),
  status text not null default 'Pendente' check (status in ('Pendente', 'Concluida')),
  due_date date not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, new.raw_user_meta_data ->> 'full_name', new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.spaces enable row level security;
alter table public.events enable row level security;
alter table public.tasks enable row level security;

create policy "Profiles are owner readable" on public.profiles
  for select using (auth.uid() = id);
create policy "Profiles are owner updatable" on public.profiles
  for update using (auth.uid() = id);

create policy "Spaces are owner scoped" on public.spaces
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Events are owner scoped" on public.events
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Tasks are owner scoped" on public.tasks
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
