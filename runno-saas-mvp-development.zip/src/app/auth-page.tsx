import { useState } from "react";
import { RunnoLogo } from "../components/ui/runno-logo";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { isSupabaseConfigured, supabase } from "../lib/supabase";
import type { Profile } from "../types";

interface AuthPageProps {
  onAuth: (profile: Profile) => void;
}

export function AuthPage({ onAuth }: AuthPageProps) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  const onSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");

    if (!isSupabaseConfigured || !supabase) {
      if (mode === "signup" && password !== confirmPassword) {
        setError("As senhas nao conferem.");
        return;
      }
      onAuth({ id: crypto.randomUUID(), email, fullName: name || email.split("@")[0] });
      return;
    }

    if (mode === "signup" && password !== confirmPassword) {
      setError("As senhas nao conferem.");
      return;
    }

    if (mode === "login") {
      const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });
      if (authError || !data.user) {
        setError(authError?.message ?? "Falha ao entrar.");
        return;
      }
      onAuth({
        id: data.user.id,
        email: data.user.email ?? email,
        fullName: data.user.user_metadata.full_name ?? email.split("@")[0],
      });
      return;
    }

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name } },
    });

    if (signUpError || !data.user) {
      setError(signUpError?.message ?? "Falha ao criar conta.");
      return;
    }

    onAuth({ id: data.user.id, email: data.user.email ?? email, fullName: name || email.split("@")[0] });
  };

  return (
    <div className="grid min-h-screen place-items-center bg-[#0B0B0F] px-4 text-zinc-100">
      <div className="w-full max-w-md space-y-6 rounded-3xl border border-zinc-800 bg-[#15151C]/90 p-8 backdrop-blur">
        <div>
          <RunnoLogo className="mb-3" />
          <h1 className="text-3xl font-semibold">{mode === "login" ? "Entrar" : "Criar conta"}</h1>
        </div>

        <form className="space-y-3" onSubmit={onSubmit}>
          {mode === "signup" && (
            <Input placeholder="Nome completo" value={name} onChange={(event) => setName(event.target.value)} required />
          )}
          <Input type="email" placeholder="Email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          <Input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            required
          />
          {mode === "signup" && (
            <Input
              type="password"
              placeholder="Confirmar senha"
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              required
            />
          )}
          {error && <p className="text-sm text-red-400">{error}</p>}
          {!isSupabaseConfigured && (
            <p className="text-xs text-zinc-500">Modo demo ativo. Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY.</p>
          )}
          <Button type="submit" className="w-full">
            {mode === "login" ? "Entrar" : "Criar conta"}
          </Button>
        </form>

        <div className="flex items-center justify-between text-sm">
          <button className="text-zinc-400 hover:text-zinc-200">Esqueci minha senha</button>
          <button
            className="text-zinc-400 hover:text-zinc-200"
            onClick={() => setMode((previous) => (previous === "login" ? "signup" : "login"))}
          >
            {mode === "login" ? "Criar conta" : "Ja possui conta? Entrar"}
          </button>
        </div>
      </div>
    </div>
  );
}
