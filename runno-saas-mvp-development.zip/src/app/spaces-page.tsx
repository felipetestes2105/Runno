import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Modal } from "../components/ui/modal";
import { SpaceBreadcrumb } from "../components/spaces/space-breadcrumb";
import type { Space } from "../types";

interface SpacesPageProps {
  spaces: Space[];
  currentSpaceId: string | null;
  onCreateSpace: (space: Omit<Space, "id" | "createdAt" | "userId">) => void;
  onUpdateSpace: (spaceId: string, space: Partial<Space>) => void;
  onDeleteSpace: (spaceId: string) => void;
  onSelectSpace: (spaceId: string) => void;
}

const defaultForm = { company: "", unit: "" };

export function SpacesPage({
  spaces,
  currentSpaceId,
  onCreateSpace,
  onUpdateSpace,
  onDeleteSpace,
  onSelectSpace,
}: SpacesPageProps) {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(defaultForm);

  const saveSpace = () => {
    if (!form.company.trim() || !form.unit.trim()) return;
    if (editingId) {
      onUpdateSpace(editingId, form);
    } else {
      onCreateSpace(form);
    }
    setOpen(false);
    setEditingId(null);
    setForm(defaultForm);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-semibold">Espacos</h2>
          <p className="text-zinc-500">Cada rotina pertence a um espaco com empresa e unidade.</p>
        </div>
        <Button
          onClick={() => {
            setEditingId(null);
            setForm(defaultForm);
            setOpen(true);
          }}
        >
          Novo espaco
        </Button>
      </div>

      <section className="space-y-3">
        {spaces.map((space) => (
          <div
            key={space.id}
            onClick={() => onSelectSpace(space.id)}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onSelectSpace(space.id);
              }
            }}
            tabIndex={0}
            role="button"
            className={`flex cursor-pointer flex-wrap items-center justify-between gap-3 rounded-3xl border p-4 ${
              currentSpaceId === space.id ? "border-violet-500 bg-violet-500/10" : "border-zinc-800 bg-[#15151C]/85"
            }`}
          >
            <div className="text-left">
              <SpaceBreadcrumb company={space.company} unit={space.unit} />
            </div>
            <div className="flex gap-2">
              <Button
                variant="secondary"
                className="h-8 px-3"
                onClick={(event) => {
                  event.stopPropagation();
                  onSelectSpace(space.id);
                }}
              >
                Selecionar
              </Button>
              <Button
                variant="ghost"
                className="h-8 px-3"
                onClick={(event) => {
                  event.stopPropagation();
                  setEditingId(space.id);
                  setForm({ company: space.company, unit: space.unit });
                  setOpen(true);
                }}
              >
                Editar
              </Button>
              <Button
                variant="danger"
                className="h-8 px-3"
                onClick={(event) => {
                  event.stopPropagation();
                  onDeleteSpace(space.id);
                }}
              >
                Excluir
              </Button>
            </div>
          </div>
        ))}
      </section>

      <Modal open={open} onClose={() => setOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingId ? "Editar espaco" : "Novo espaco"}</h3>
          <Input
            placeholder="Empresa"
            value={form.company}
            onChange={(event) => setForm((previous) => ({ ...previous, company: event.target.value }))}
          />
          <Input
            placeholder="Unidade"
            value={form.unit}
            onChange={(event) => setForm((previous) => ({ ...previous, unit: event.target.value }))}
          />
          <Button className="w-full" onClick={saveSpace}>
            Salvar espaco
          </Button>
        </div>
      </Modal>
    </div>
  );
}
