import { useMemo, useState } from "react";
import { Heart, HeartOff, Pencil, Pin, PinOff, Trash2 } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Modal } from "../components/ui/modal";
import { Select } from "../components/ui/select";
import type { AwaitingItem, DeadlineItem, EventItem, NoteItem, TaskItem } from "../types";

interface NotesPageProps {
  notes: NoteItem[];
  tasks: TaskItem[];
  events: EventItem[];
  deadlines: DeadlineItem[];
  awaiting: AwaitingItem[];
  onCreateNote: (input: Omit<NoteItem, "id" | "userId" | "spaceId" | "createdAt">) => void;
  onUpdateNote: (noteId: string, input: Partial<NoteItem>) => void;
  onDeleteNote: (noteId: string) => void;
}

const defaultForm = {
  title: "",
  content: "",
  category: "Geral",
  tags: "",
  linkedType: "none" as NoteItem["linkedType"],
  linkedId: "",
};

export function NotesPage({ notes, tasks, events, deadlines, awaiting, onCreateNote, onUpdateNote, onDeleteNote }: NotesPageProps) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(defaultForm);

  const linkedOptions = useMemo(() => {
    if (form.linkedType === "task") return tasks.map((item) => ({ id: item.id, label: item.title }));
    if (form.linkedType === "event") return events.map((item) => ({ id: item.id, label: item.title }));
    if (form.linkedType === "deadline") return deadlines.map((item) => ({ id: item.id, label: item.title }));
    if (form.linkedType === "awaiting") return awaiting.map((item) => ({ id: item.id, label: item.title }));
    return [];
  }, [awaiting, deadlines, events, form.linkedType, tasks]);

  const filteredNotes = useMemo(() => {
    const normalized = query.toLowerCase();
    return notes
      .filter((note) => `${note.title} ${note.content} ${note.tags.join(" ")}`.toLowerCase().includes(normalized))
      .sort((left, right) => Number(right.pinned) - Number(left.pinned) || Number(right.favorite) - Number(left.favorite));
  }, [notes, query]);

  const saveNote = () => {
    if (!form.title.trim()) return;

    const payload: Omit<NoteItem, "id" | "userId" | "spaceId" | "createdAt"> = {
      title: form.title,
      content: form.content,
      category: form.category,
      tags: form.tags
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
      pinned: false,
      favorite: false,
      linkedType: form.linkedType,
      linkedId: form.linkedType === "none" ? null : form.linkedId || null,
    };

    if (editingId) {
      onUpdateNote(editingId, payload);
    } else {
      onCreateNote(payload);
    }

    setOpen(false);
    setEditingId(null);
    setForm(defaultForm);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-3xl font-semibold">Anotacoes</h2>
          <p className="text-zinc-500">Registro rapido, vinculacoes e acompanhamento operacional.</p>
        </div>
        <Button
          onClick={() => {
            setEditingId(null);
            setForm(defaultForm);
            setOpen(true);
          }}
        >
          Nova anotacao
        </Button>
      </div>

      <Input placeholder="Pesquisar anotacoes..." value={query} onChange={(event) => setQuery(event.target.value)} />

      <section className="space-y-3">
        {filteredNotes.map((note) => (
          <div key={note.id} className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-base text-zinc-100">{note.title}</p>
                <p className="text-xs text-zinc-500">
                  {note.category} | {note.tags.join(", ") || "Sem tags"}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  className="h-8 px-3"
                  title={note.favorite ? "Desfavoritar" : "Favoritar"}
                  onClick={() => onUpdateNote(note.id, { favorite: !note.favorite })}
                >
                  {note.favorite ? <HeartOff size={14} /> : <Heart size={14} />}
                </Button>
                <Button
                  variant="ghost"
                  className="h-8 px-3"
                  title={note.pinned ? "Desfixar" : "Fixar"}
                  onClick={() => onUpdateNote(note.id, { pinned: !note.pinned })}
                >
                  {note.pinned ? <PinOff size={14} /> : <Pin size={14} />}
                </Button>
                <Button
                  variant="ghost"
                  className="h-8 px-3"
                  title="Editar"
                  onClick={() => {
                    setEditingId(note.id);
                    setForm({
                      title: note.title,
                      content: note.content,
                      category: note.category,
                      tags: note.tags.join(", "),
                      linkedType: note.linkedType,
                      linkedId: note.linkedId ?? "",
                    });
                    setOpen(true);
                  }}
                >
                  <Pencil size={14} />
                </Button>
                <Button variant="danger" className="h-8 px-3" title="Excluir" onClick={() => onDeleteNote(note.id)}>
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
            <p className="mt-3 text-sm text-zinc-300">{note.content}</p>
            <p className="mt-2 text-xs text-zinc-500">
              Vinculada: {note.linkedType === "none" ? "Nao" : `${note.linkedType} (${note.linkedId ?? "-"})`}
            </p>
          </div>
        ))}
        {filteredNotes.length === 0 && <p className="text-sm text-zinc-500">Nenhuma anotacao encontrada.</p>}
      </section>

      <Modal open={open} onClose={() => setOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingId ? "Editar anotacao" : "Nova anotacao"}</h3>
          <Input placeholder="Titulo" value={form.title} onChange={(event) => setForm((previous) => ({ ...previous, title: event.target.value }))} />
          <Input placeholder="Conteudo" value={form.content} onChange={(event) => setForm((previous) => ({ ...previous, content: event.target.value }))} />
          <div className="grid grid-cols-2 gap-3">
            <Input placeholder="Categoria" value={form.category} onChange={(event) => setForm((previous) => ({ ...previous, category: event.target.value }))} />
            <Input placeholder="Tags (separadas por virgula)" value={form.tags} onChange={(event) => setForm((previous) => ({ ...previous, tags: event.target.value }))} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Select
              value={form.linkedType}
              onChange={(event) => setForm((previous) => ({ ...previous, linkedType: event.target.value as NoteItem["linkedType"], linkedId: "" }))}
            >
              <option value="none">Sem vinculacao</option>
              <option value="task">Tarefa</option>
              <option value="event">Evento</option>
              <option value="deadline">Prazo</option>
              <option value="awaiting">Aguardando</option>
            </Select>
            <Select
              value={form.linkedId}
              onChange={(event) => setForm((previous) => ({ ...previous, linkedId: event.target.value }))}
              disabled={form.linkedType === "none"}
            >
              <option value="">Selecione</option>
              {linkedOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label}
                </option>
              ))}
            </Select>
          </div>
          <Button className="w-full" onClick={saveNote}>
            Salvar anotacao
          </Button>
        </div>
      </Modal>
    </div>
  );
}
