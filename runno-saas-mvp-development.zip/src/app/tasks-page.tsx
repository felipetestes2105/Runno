import { useMemo, useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Modal } from "../components/ui/modal";
import { Select } from "../components/ui/select";
import { TaskItemRow } from "../components/tasks/task-item-row";
import { taskPriorityRank } from "../lib/task-priority";
import type { EventCategory, NoteItem, TaskItem, TaskPriority, TaskStatus } from "../types";

interface TasksPageProps {
  tasks: TaskItem[];
  notes: NoteItem[];
  onCreateTask: (task: Omit<TaskItem, "id" | "userId" | "spaceId">) => void;
  onUpdateTask: (taskId: string, task: Partial<TaskItem>) => void;
  onDeleteTask: (taskId: string) => void;
  onToggleTask: (taskId: string) => void;
}

const categories: EventCategory[] = ["Administrativo", "Financeiro", "RH", "Compras", "Pessoal"];
const priorities: TaskPriority[] = ["Critica", "Importante", "Normal"];
const statuses: TaskStatus[] = ["Pendente", "Concluida"];

const defaultForm = {
  title: "",
  description: "",
  category: "Administrativo" as EventCategory,
  priority: "Normal" as TaskPriority,
  status: "Pendente" as TaskStatus,
  dueDate: new Date().toISOString().slice(0, 10),
  time: "",
  reminder: "",
  deadline: "",
  notesLinked: "",
  recurring: false,
  repeat: "daily" as "daily" | "weekly" | "monthly" | "yearly" | "custom",
  weeklyDays: [1],
  monthlyMode: "dayOfMonth" as "dayOfMonth" | "dayOfWeek",
  customInterval: 2,
  customUnit: "days" as "days" | "weeks" | "months" | "years",
  endType: "never" as "never" | "untilDate" | "occurrences",
  untilDate: "",
  occurrences: 10,
};

export function TasksPage({ tasks, notes, onCreateTask, onUpdateTask, onDeleteTask, onToggleTask }: TasksPageProps) {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(defaultForm);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const orderedTasks = useMemo(
    () =>
      [...tasks].sort(
        (left, right) =>
          taskPriorityRank(left.priority) - taskPriorityRank(right.priority) || left.dueDate.localeCompare(right.dueDate)
      ),
    [tasks]
  );

  const pendingTasks = orderedTasks.filter((task) => task.status === "Pendente");
  const completedTasks = orderedTasks.filter((task) => task.status === "Concluida");

  const saveTask = () => {
    if (!form.title.trim()) return;

    const payload = {
      title: form.title,
      description: form.description,
      category: form.category,
      priority: form.priority,
      status: form.status,
      dueDate: form.dueDate,
      time: form.time || undefined,
      reminder: form.reminder || undefined,
      deadline: form.deadline || undefined,
      notesLinked: form.notesLinked
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
      recurrence: form.recurring
        ? {
            enabled: true,
            repeat: form.repeat,
            weeklyDays: form.weeklyDays,
            monthlyMode: form.monthlyMode,
            customInterval: form.customInterval,
            customUnit: form.customUnit,
            endType: form.endType,
            untilDate: form.endType === "untilDate" ? form.untilDate || null : null,
            occurrences: form.endType === "occurrences" ? form.occurrences : null,
          }
        : undefined,
    };

    if (editingId) {
      const current = tasks.find((task) => task.id === editingId);
      if (current?.recurrence?.enabled) {
        const editSeries = window.confirm("Editar toda a serie? Cancelar aplica somente esta ocorrencia.");
        if (editSeries) {
          onUpdateTask(editingId, payload);
        } else {
          onCreateTask({ ...payload, recurrence: undefined });
        }
      } else {
        onUpdateTask(editingId, payload);
      }
    } else {
      onCreateTask(payload);
    }

    setOpen(false);
    setEditingId(null);
    setForm(defaultForm);
    setShowAdvanced(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-semibold">Tarefas</h2>
          <p className="text-zinc-500">Criacao rapida com opcoes avancadas sob demanda.</p>
        </div>
        <Button
          onClick={() => {
            setEditingId(null);
            setForm(defaultForm);
            setShowAdvanced(false);
            setOpen(true);
          }}
        >
          Nova tarefa
        </Button>
      </div>

      <section className="space-y-3">
        <h3 className="text-lg font-medium text-zinc-100">Pendentes</h3>
        {pendingTasks.map((task) => (
          <div key={task.id}>
            <TaskItemRow
              task={task}
              onToggle={onToggleTask}
              onDelete={onDeleteTask}
              onEdit={(item) => {
                setEditingId(item.id);
                setForm({
                  title: item.title,
                  description: item.description,
                  category: item.category,
                  priority: item.priority,
                  status: item.status,
                  dueDate: item.dueDate,
                  time: item.time ?? "",
                  reminder: item.reminder ?? "",
                  deadline: item.deadline ?? "",
                  notesLinked: item.notesLinked?.join(", ") ?? "",
                  recurring: item.recurrence?.enabled ?? false,
                  repeat: item.recurrence?.repeat ?? "daily",
                  weeklyDays: item.recurrence?.weeklyDays ?? [1],
                  monthlyMode: item.recurrence?.monthlyMode ?? "dayOfMonth",
                  customInterval: item.recurrence?.customInterval ?? 2,
                  customUnit: item.recurrence?.customUnit ?? "days",
                  endType: item.recurrence?.endType ?? "never",
                  untilDate: item.recurrence?.untilDate ?? "",
                  occurrences: item.recurrence?.occurrences ?? 10,
                });
                setShowAdvanced(Boolean(item.description || item.time || item.reminder || item.deadline || item.recurrence?.enabled));
                setOpen(true);
              }}
            />
            <div className="mt-1 text-xs text-zinc-500">
              Anotacoes vinculadas: {notes.filter((note) => note.linkedType === "task" && note.linkedId === task.id).length}
            </div>
          </div>
        ))}
      </section>

      <section className="space-y-3">
        <h3 className="text-lg font-medium text-zinc-100">Concluidas</h3>
        {completedTasks.map((task) => (
          <TaskItemRow
            key={task.id}
            task={task}
            onToggle={onToggleTask}
            onDelete={onDeleteTask}
            onEdit={(item) => {
              setEditingId(item.id);
              setForm({
                title: item.title,
                description: item.description,
                category: item.category,
                priority: item.priority,
                status: item.status,
                dueDate: item.dueDate,
                time: item.time ?? "",
                reminder: item.reminder ?? "",
                deadline: item.deadline ?? "",
                notesLinked: item.notesLinked?.join(", ") ?? "",
                recurring: item.recurrence?.enabled ?? false,
                repeat: item.recurrence?.repeat ?? "daily",
                weeklyDays: item.recurrence?.weeklyDays ?? [1],
                monthlyMode: item.recurrence?.monthlyMode ?? "dayOfMonth",
                customInterval: item.recurrence?.customInterval ?? 2,
                customUnit: item.recurrence?.customUnit ?? "days",
                endType: item.recurrence?.endType ?? "never",
                untilDate: item.recurrence?.untilDate ?? "",
                occurrences: item.recurrence?.occurrences ?? 10,
              });
              setShowAdvanced(true);
              setOpen(true);
            }}
          />
        ))}
      </section>

      <Modal open={open} onClose={() => setOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingId ? "Editar tarefa" : "Nova tarefa"}</h3>
          <Input placeholder="Titulo" value={form.title} onChange={(event) => setForm((previous) => ({ ...previous, title: event.target.value }))} />
          <div className="grid grid-cols-2 gap-3">
            <Input type="date" value={form.dueDate} onChange={(event) => setForm((previous) => ({ ...previous, dueDate: event.target.value }))} />
            <Select value={form.priority} onChange={(event) => setForm((previous) => ({ ...previous, priority: event.target.value as TaskPriority }))}>
              {priorities.map((priority) => (
                <option key={priority}>{priority}</option>
              ))}
            </Select>
          </div>

          <p className="text-xs text-zinc-500">Espaco: tarefa sera criada no espaco atualmente selecionado.</p>

          <button className="text-sm text-violet-300" onClick={() => setShowAdvanced((previous) => !previous)}>
            {showAdvanced ? "Ocultar campos avancados" : "Mostrar campos avancados"}
          </button>

          {showAdvanced && (
            <>
              <Input
                placeholder="Descricao"
                value={form.description}
                onChange={(event) => setForm((previous) => ({ ...previous, description: event.target.value }))}
              />
              <div className="grid grid-cols-2 gap-3">
                <Input type="time" value={form.time} onChange={(event) => setForm((previous) => ({ ...previous, time: event.target.value }))} />
                <Select
                  value={form.category}
                  onChange={(event) => setForm((previous) => ({ ...previous, category: event.target.value as EventCategory }))}
                >
                  {categories.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Lembrete" value={form.reminder} onChange={(event) => setForm((previous) => ({ ...previous, reminder: event.target.value }))} />
                <Input placeholder="Prazo" value={form.deadline} onChange={(event) => setForm((previous) => ({ ...previous, deadline: event.target.value }))} />
              </div>
              <Input
                placeholder="Anotacoes vinculadas (separadas por virgula)"
                value={form.notesLinked}
                onChange={(event) => setForm((previous) => ({ ...previous, notesLinked: event.target.value }))}
              />
            </>
          )}

          <div className="rounded-2xl border border-zinc-800 p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-sm text-zinc-200">Repetir tarefa</p>
              <button
                className={`h-6 w-11 rounded-full transition ${form.recurring ? "bg-violet-500" : "bg-zinc-700"}`}
                onClick={() => setForm((previous) => ({ ...previous, recurring: !previous.recurring }))}
              >
                <span
                  className={`block h-5 w-5 rounded-full bg-white transition ${form.recurring ? "translate-x-5" : "translate-x-0.5"}`}
                />
              </button>
            </div>

            {form.recurring && (
              <div className="space-y-2">
                <Select
                  value={form.repeat}
                  onChange={(event) => setForm((previous) => ({ ...previous, repeat: event.target.value as typeof form.repeat }))}
                >
                  <option value="daily">Diariamente</option>
                  <option value="weekly">Semanalmente</option>
                  <option value="monthly">Mensalmente</option>
                  <option value="yearly">Anualmente</option>
                  <option value="custom">Personalizado</option>
                </Select>

                {form.repeat === "weekly" && (
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-1">
                      {[
                        { label: "Seg", value: 1 },
                        { label: "Ter", value: 2 },
                        { label: "Qua", value: 3 },
                        { label: "Qui", value: 4 },
                        { label: "Sex", value: 5 },
                        { label: "Sab", value: 6 },
                        { label: "Dom", value: 7 },
                      ].map((day) => (
                        <button
                          key={day.value}
                          className={`rounded-lg border px-2 py-1 text-xs ${
                            form.weeklyDays.includes(day.value) ? "border-violet-500 bg-violet-500/20" : "border-zinc-700"
                          }`}
                          onClick={() =>
                            setForm((previous) => ({
                              ...previous,
                              weeklyDays: previous.weeklyDays.includes(day.value)
                                ? previous.weeklyDays.filter((value) => value !== day.value)
                                : [...previous.weeklyDays, day.value],
                            }))
                          }
                        >
                          {day.label}
                        </button>
                      ))}
                    </div>
                    <button
                      className="text-xs text-violet-300"
                      onClick={() => setForm((previous) => ({ ...previous, weeklyDays: [1, 2, 3, 4, 5] }))}
                    >
                      Dias uteis
                    </button>
                  </div>
                )}

                {form.repeat === "monthly" && (
                  <Select
                    value={form.monthlyMode}
                    onChange={(event) => setForm((previous) => ({ ...previous, monthlyMode: event.target.value as typeof form.monthlyMode }))}
                  >
                    <option value="dayOfMonth">Mesmo dia do mes</option>
                    <option value="dayOfWeek">Mesmo dia da semana</option>
                  </Select>
                )}

                {form.repeat === "custom" && (
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      min={1}
                      value={form.customInterval}
                      onChange={(event) => setForm((previous) => ({ ...previous, customInterval: Number(event.target.value) || 1 }))}
                    />
                    <Select
                      value={form.customUnit}
                      onChange={(event) => setForm((previous) => ({ ...previous, customUnit: event.target.value as typeof form.customUnit }))}
                    >
                      <option value="days">Dias</option>
                      <option value="weeks">Semanas</option>
                      <option value="months">Meses</option>
                      <option value="years">Anos</option>
                    </Select>
                  </div>
                )}

                <Select
                  value={form.endType}
                  onChange={(event) => setForm((previous) => ({ ...previous, endType: event.target.value as typeof form.endType }))}
                >
                  <option value="never">Nunca termina</option>
                  <option value="untilDate">Ate uma data</option>
                  <option value="occurrences">Quantidade de repeticoes</option>
                </Select>

                {form.endType === "untilDate" && (
                  <Input type="date" value={form.untilDate} onChange={(event) => setForm((previous) => ({ ...previous, untilDate: event.target.value }))} />
                )}
                {form.endType === "occurrences" && (
                  <Input
                    type="number"
                    min={1}
                    value={form.occurrences}
                    onChange={(event) => setForm((previous) => ({ ...previous, occurrences: Number(event.target.value) || 1 }))}
                  />
                )}
              </div>
            )}
          </div>

          <Select
            value={form.status}
            onChange={(event) => setForm((previous) => ({ ...previous, status: event.target.value as TaskStatus }))}
          >
            {statuses.map((status) => (
              <option key={status}>{status}</option>
            ))}
          </Select>

          <Button className="w-full" onClick={saveTask}>
            Salvar tarefa
          </Button>
        </div>
      </Modal>
    </div>
  );
}
