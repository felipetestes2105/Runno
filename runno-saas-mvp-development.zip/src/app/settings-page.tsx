import type { Profile, Space, ThemePreference } from "../types";

interface SettingsPageProps {
  profile: Profile;
  spaces: Space[];
  themePreference: ThemePreference;
  onThemeChange: (theme: ThemePreference) => void;
}

export function SettingsPage({ profile, spaces, themePreference, onThemeChange }: SettingsPageProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-semibold">Configuracoes</h2>
        <p className="text-zinc-500">Ajustes iniciais do perfil, aparencia e espacos.</p>
      </div>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-5">
        <h3 className="text-lg font-medium">Perfil</h3>
        <p className="mt-2 text-sm text-zinc-400">Nome: {profile.fullName}</p>
        <p className="text-sm text-zinc-400">Email: {profile.email}</p>
      </section>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-5">
        <h3 className="text-lg font-medium">Aparencia</h3>
        <p className="mt-2 text-sm text-zinc-400">Escolha como a interface deve ser exibida.</p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {[
            { key: "light", label: "Claro" },
            { key: "dark", label: "Escuro" },
            { key: "system", label: "Seguir sistema" },
          ].map((option) => (
            <button
              key={option.key}
              className={`rounded-2xl border px-3 py-2 text-sm transition ${
                themePreference === option.key
                  ? "border-violet-500 bg-violet-500/10 text-zinc-100"
                  : "border-zinc-700 text-zinc-400 hover:border-zinc-500 hover:text-zinc-200"
              }`}
              onClick={() => onThemeChange(option.key as ThemePreference)}
            >
              {option.label}
            </button>
          ))}
        </div>
      </section>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-5">
        <h3 className="text-lg font-medium">Espacos</h3>
        <p className="mt-2 text-sm text-zinc-400">Total de espacos cadastrados: {spaces.length}</p>
      </section>
    </div>
  );
}
