import { useMemo, useState, type DragEvent } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUp,
  Clock3,
  ChevronDown,
  ChevronUp,
  CalendarDays,
  CheckCircle2,
  Eye,
  Filter,
  NotebookPen,
  Pencil,
  Pin,
  PinOff,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { TaskItemRow } from "../components/tasks/task-item-row";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Modal } from "../components/ui/modal";
import { Select } from "../components/ui/select";
import { formatDateBR } from "../lib/date-format";
import { taskPriorityRank } from "../lib/task-priority";
import type { AwaitingItem, DeadlineItem, EventCategory, EventItem, NoteItem, TaskItem, TaskPriority } from "../types";

interface DashboardPageProps {
  tasks: TaskItem[];
  events: EventItem[];
  awaiting: AwaitingItem[];
  deadlines: DeadlineItem[];
  notes: NoteItem[];
  onCreateTask: (task: Omit<TaskItem, "id" | "userId" | "spaceId">) => void;
  onUpdateTask: (taskId: string, task: Partial<TaskItem>) => void;
  onDeleteTask: (taskId: string) => void;
  onToggleTask: (taskId: string) => void;
  onCreateAwaiting: (input: Omit<AwaitingItem, "id" | "userId" | "spaceId" | "createdAt">) => void;
  onUpdateAwaiting: (itemId: string, input: Partial<AwaitingItem>) => void;
  onDeleteAwaiting: (itemId: string) => void;
  onCreateDeadline: (input: Omit<DeadlineItem, "id" | "userId" | "spaceId">) => void;
  onUpdateDeadline: (deadlineId: string, input: Partial<DeadlineItem>) => void;
  onDeleteDeadline: (deadlineId: string) => void;
  onCreateNote: (input: Omit<NoteItem, "id" | "userId" | "spaceId" | "createdAt">) => void;
  onUpdateNote: (noteId: string, input: Partial<NoteItem>) => void;
  onDeleteNote: (noteId: string) => void;
  onUpdateEvent: (eventId: string, input: Partial<EventItem>) => void;
  onDeleteEvent: (eventId: string) => void;
  onOpenCalendar: () => void;
}

const defaultTask = {
  title: "",
  description: "",
  priority: "Normal" as TaskPriority,
  dueDate: new Date().toISOString().slice(0, 10),
  category: "Administrativo" as EventCategory,
  time: "",
  recurring: false,
  repeat: "daily" as "daily" | "weekly" | "monthly" | "yearly" | "custom",
  weeklyDays: [1],
  monthlyMode: "dayOfMonth" as "dayOfMonth" | "dayOfWeek",
  customInterval: 2,
  customUnit: "days" as "days" | "weeks" | "months" | "years",
  endType: "never" as "never" | "untilDate" | "occurrences",
  untilDate: "",
  occurrences: 10,
};

export function DashboardPage({
  tasks,
  events,
  awaiting,
  deadlines,
  notes,
  onCreateTask,
  onUpdateTask,
  onDeleteTask,
  onToggleTask,
  onCreateAwaiting,
  onUpdateAwaiting,
  onDeleteAwaiting,
  onCreateDeadline,
  onUpdateDeadline,
  onDeleteDeadline,
  onCreateNote,
  onUpdateNote,
  onDeleteNote,
  onUpdateEvent,
  onDeleteEvent,
  onOpenCalendar,
}: DashboardPageProps) {
  const today = new Date().toISOString().slice(0, 10);
  const [taskModal, setTaskModal] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [taskForm, setTaskForm] = useState(defaultTask);
  const [showTaskAdvanced, setShowTaskAdvanced] = useState(false);
  const [taskQuery, setTaskQuery] = useState("");
  const [taskFilter, setTaskFilter] = useState<"Todas" | TaskPriority | "Concluida">("Todas");
  const [dateFilter, setDateFilter] = useState<"Hoje" | "Futuras" | "Passadas" | "Personalizado">("Hoje");
  const [customFrom, setCustomFrom] = useState(today);
  const [customTo, setCustomTo] = useState(today);
  const [manualOrder, setManualOrder] = useState<string[]>([]);
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);

  const [awaitingModal, setAwaitingModal] = useState(false);
  const [awaitingTitle, setAwaitingTitle] = useState("");
  const [awaitingDesc, setAwaitingDesc] = useState("");
  const [editingAwaitingId, setEditingAwaitingId] = useState<string | null>(null);

  const [deadlineModal, setDeadlineModal] = useState(false);
  const [editingDeadlineId, setEditingDeadlineId] = useState<string | null>(null);
  const [expandedDeadlineId, setExpandedDeadlineId] = useState<string | null>(null);
  const [deadlineOrder, setDeadlineOrder] = useState<string[]>([]);
  const [deadlineTitle, setDeadlineTitle] = useState("");
  const [deadlineDescription, setDeadlineDescription] = useState("");
  const [deadlineDate, setDeadlineDate] = useState(today);
  const [deadlineTime, setDeadlineTime] = useState("");
  const [deadlinePriority, setDeadlinePriority] = useState<TaskPriority>("Importante");

  const [noteModal, setNoteModal] = useState(false);
  const [noteSearch, setNoteSearch] = useState("");
  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteOrder, setNoteOrder] = useState<string[]>([]);
  const [noteDetailId, setNoteDetailId] = useState<string | null>(null);

  const [eventEditOpen, setEventEditOpen] = useState(false);
  const [eventDetailOpen, setEventDetailOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<EventItem | null>(null);

  const withinDateFilter = (date: string) => {
    if (dateFilter === "Hoje") return date === today;
    if (dateFilter === "Futuras") return date > today;
    if (dateFilter === "Passadas") return date < today;
    return date >= customFrom && date <= customTo;
  };

  const taskBase = useMemo(() => {
    const pending = tasks
      .filter((task) => withinDateFilter(task.dueDate) && task.status === "Pendente")
      .sort((left, right) => taskPriorityRank(left.priority) - taskPriorityRank(right.priority));
    const completed = tasks.filter((task) => withinDateFilter(task.dueDate) && task.status === "Concluida");
    return [...pending, ...completed];
  }, [tasks, dateFilter, customFrom, customTo]);

  const taskMap = useMemo(() => new Map(taskBase.map((task) => [task.id, task])), [taskBase]);
  const orderedTasks = useMemo(() => {
    const validManual = manualOrder.filter((id) => taskMap.has(id));
    const manualItems = validManual.map((id) => taskMap.get(id)).filter(Boolean) as TaskItem[];
    const remaining = taskBase.filter((task) => !validManual.includes(task.id));
    return [...manualItems, ...remaining];
  }, [manualOrder, taskBase, taskMap]);

  const visibleTasks = orderedTasks.filter((task) => {
    const matchesQuery = `${task.title} ${task.description}`.toLowerCase().includes(taskQuery.toLowerCase());
    const matchesFilter =
      taskFilter === "Todas" ||
      (taskFilter === "Concluida" ? task.status === "Concluida" : task.priority === taskFilter);
    return matchesQuery && matchesFilter;
  });

  const filteredEvents = events.filter((event) => withinDateFilter(event.date)).sort((left, right) => `${left.date}${left.time}`.localeCompare(`${right.date}${right.time}`));

  const visibleNotes = useMemo(() => {
    const filtered = notes
      .filter((note) => `${note.title} ${note.content}`.toLowerCase().includes(noteSearch.toLowerCase()))
      .sort((left, right) => Number(right.pinned) - Number(left.pinned));
    const noteMap = new Map(filtered.map((note) => [note.id, note]));
    const validManual = noteOrder.filter((id) => noteMap.has(id));
    const manualItems = validManual.map((id) => noteMap.get(id)).filter(Boolean) as NoteItem[];
    const remaining = filtered.filter((note) => !validManual.includes(note.id));
    return [...manualItems, ...remaining].slice(0, 6);
  }, [notes, noteOrder, noteSearch]);

  const sortedDeadlines = [...deadlines].sort((left, right) => `${left.dueDate}${left.time ?? ""}`.localeCompare(`${right.dueDate}${right.time ?? ""}`));
  const orderedDeadlines = useMemo(() => {
    if (deadlineOrder.length === 0) return sortedDeadlines.slice(0, 4);
    const manual: DeadlineItem[] = [];
    for (const id of deadlineOrder) {
      const found = sortedDeadlines.find((item) => item.id === id);
      if (found) manual.push(found);
    }
    const remaining = sortedDeadlines.filter((item) => !deadlineOrder.includes(item.id));
    return [...manual, ...remaining].slice(0, 4);
  }, [deadlineOrder, sortedDeadlines]);

  const moveDeadline = (deadlineId: string, direction: "up" | "down") => {
    setDeadlineOrder((previous) => {
      const base = previous.length > 0 ? [...previous] : sortedDeadlines.map((item) => item.id);
      const index = base.indexOf(deadlineId);
      if (index < 0) return previous;
      const target = direction === "up" ? index - 1 : index + 1;
      if (target < 0 || target >= base.length) return previous;
      const next = [...base];
      const [item] = next.splice(index, 1);
      next.splice(target, 0, item);
      return next;
    });
  };

  const moveTask = (taskId: string, direction: "up" | "down") => {
    setManualOrder((previous) => {
      const base = previous.length > 0 ? [...previous] : orderedTasks.map((task) => task.id);
      const index = base.indexOf(taskId);
      if (index < 0) return previous;
      const target = direction === "up" ? index - 1 : index + 1;
      if (target < 0 || target >= base.length) return previous;
      const next = [...base];
      const [item] = next.splice(index, 1);
      next.splice(target, 0, item);
      return next;
    });
  };

  const dragTask = (taskId: string, event: DragEvent<HTMLDivElement>) => {
    event.dataTransfer.setData("text/task-id", taskId);
  };

  const dropTask = (targetId: string, event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const sourceId = event.dataTransfer.getData("text/task-id");
    if (!sourceId || sourceId === targetId) return;
    setManualOrder((previous) => {
      const base = previous.length > 0 ? [...previous] : orderedTasks.map((task) => task.id);
      const sourceIndex = base.indexOf(sourceId);
      const targetIndex = base.indexOf(targetId);
      if (sourceIndex < 0 || targetIndex < 0) return previous;
      const next = [...base];
      const [item] = next.splice(sourceIndex, 1);
      next.splice(targetIndex, 0, item);
      return next;
    });
  };

  const moveNote = (noteId: string, direction: "up" | "down") => {
    setNoteOrder((previous) => {
      const base = previous.length > 0 ? [...previous] : visibleNotes.map((note) => note.id);
      const index = base.indexOf(noteId);
      if (index < 0) return previous;
      const target = direction === "up" ? index - 1 : index + 1;
      if (target < 0 || target >= base.length) return previous;
      const next = [...base];
      const [item] = next.splice(index, 1);
      next.splice(target, 0, item);
      return next;
    });
  };

  const noteDetail = notes.find((note) => note.id === noteDetailId) ?? null;

  const mixedAgenda = useMemo(() => {
    const tasksMapped = visibleTasks.map((task) => ({ id: task.id, type: "task" as const, date: task.dueDate, time: "", task }));
    const eventsMapped = filteredEvents.map((event) => ({ id: event.id, type: "event" as const, date: event.date, time: event.time, event }));
    return [...tasksMapped, ...eventsMapped].sort((left, right) => `${left.date}${left.time}`.localeCompare(`${right.date}${right.time}`));
  }, [visibleTasks, filteredEvents]);

  return (
    <div className="grid h-[calc(100vh-6.7rem)] gap-4 overflow-hidden xl:grid-cols-[1.45fr_1fr_0.9fr]">
      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-4 xl:row-span-2">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-lg font-semibold">Agenda do Dia</h3>
          <Button
            className="h-8 px-3"
            onClick={() => {
              setEditingTaskId(null);
              setTaskForm(defaultTask);
              setShowTaskAdvanced(false);
              setTaskModal(true);
            }}
          >
            <Plus size={14} className="mr-1" />
            Adicionar
          </Button>
        </div>

        <div className="mb-2 grid gap-2 sm:grid-cols-[1fr_auto]">
          <div className="relative">
            <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <Input className="h-9 pl-8" placeholder="Pesquisar..." value={taskQuery} onChange={(event) => setTaskQuery(event.target.value)} />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-zinc-500" />
            <Select className="h-9" value={taskFilter} onChange={(event) => setTaskFilter(event.target.value as typeof taskFilter)}>
              <option>Todas</option>
              <option>Critica</option>
              <option>Importante</option>
              <option>Normal</option>
              <option>Concluida</option>
            </Select>
          </div>
        </div>

        <div className="mb-2 grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
          <Select className="h-9" value={dateFilter} onChange={(event) => setDateFilter(event.target.value as typeof dateFilter)}>
            <option>Hoje</option>
            <option>Futuras</option>
            <option>Passadas</option>
            <option>Personalizado</option>
          </Select>
          {dateFilter === "Personalizado" && (
            <>
              <Input className="h-9" type="date" value={customFrom} onChange={(event) => setCustomFrom(event.target.value)} />
              <Input className="h-9" type="date" value={customTo} onChange={(event) => setCustomTo(event.target.value)} />
            </>
          )}
        </div>

        <div className="space-y-1.5 overflow-y-auto pr-1" style={{ maxHeight: "calc(100vh - 16.6rem)" }}>
          {mixedAgenda.map((item) =>
            item.type === "task" ? (
              <div key={item.id}>
                <TaskItemRow
                  task={item.task}
                  onToggle={onToggleTask}
                  onDelete={onDeleteTask}
                  onEdit={(task) => {
                    setEditingTaskId(task.id);
                    setTaskForm({
                      title: task.title,
                      description: task.description,
                      priority: task.priority,
                      dueDate: task.dueDate,
                    category: task.category,
                    time: task.time ?? "",
                    recurring: task.recurrence?.enabled ?? false,
                    repeat: task.recurrence?.repeat ?? "daily",
                    weeklyDays: task.recurrence?.weeklyDays ?? [1],
                    monthlyMode: task.recurrence?.monthlyMode ?? "dayOfMonth",
                    customInterval: task.recurrence?.customInterval ?? 2,
                    customUnit: task.recurrence?.customUnit ?? "days",
                    endType: task.recurrence?.endType ?? "never",
                    untilDate: task.recurrence?.untilDate ?? "",
                    occurrences: task.recurrence?.occurrences ?? 10,
                    });
                  setShowTaskAdvanced(Boolean(task.description || task.time || task.recurrence?.enabled));
                    setTaskModal(true);
                  }}
                  onMoveUp={() => moveTask(item.task.id, "up")}
                  onMoveDown={() => moveTask(item.task.id, "down")}
                  draggable
                  onDragStart={(event) => dragTask(item.task.id, event)}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={(event) => dropTask(item.task.id, event)}
                />
                {expandedTaskId === item.task.id && item.task.description && <p className="px-3 pt-1 text-xs text-zinc-500">{item.task.description}</p>}
                {item.task.description && (
                  <button
                    className="ml-auto mt-0.5 flex h-6 w-6 items-center justify-center rounded-md text-zinc-500 transition-all duration-200 hover:bg-zinc-900 hover:text-zinc-200"
                    onClick={() => setExpandedTaskId((previous) => (previous === item.task.id ? null : item.task.id))}
                    title={expandedTaskId === item.task.id ? "Recolher" : "Expandir"}
                  >
                    {expandedTaskId === item.task.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </button>
                )}
              </div>
            ) : (
              <div
                key={item.id}
                className="rounded-2xl border border-zinc-800 p-2.5"
                style={{ backgroundColor: `${item.event.color}CC`, color: "#FFFFFF" }}
              >
                <div className="flex items-center gap-2">
                  <Clock3 size={14} className="text-white" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-white">{item.event.title}</p>
                    <p className="text-xs text-white/80">
                      {item.event.time} | {formatDateBR(item.event.date)}
                    </p>
                  </div>
                  <div className="flex gap-0.5">
                    <Button
                      variant="ghost"
                      className="h-7 px-2"
                      title="Visualizar detalhes"
                      onClick={() => {
                        setEditingEvent(item.event);
                        setEventDetailOpen(true);
                      }}
                    >
                      <Eye size={13} />
                    </Button>
                    <Button
                      variant="ghost"
                      className="h-7 px-2"
                      title="Editar"
                      onClick={() => {
                        setEditingEvent(item.event);
                        setEventEditOpen(true);
                      }}
                    >
                      <Pencil size={13} />
                    </Button>
                    <Button
                      variant="ghost"
                      className="h-7 px-2"
                      title="Mover"
                      onClick={() => {
                        const next = new Date(item.event.date);
                        next.setDate(next.getDate() + 1);
                        onUpdateEvent(item.event.id, { date: next.toISOString().slice(0, 10) });
                      }}
                    >
                      <ArrowRight size={13} />
                    </Button>
                    <Button variant="danger" className="h-7 px-2" title="Excluir" onClick={() => onDeleteEvent(item.event.id)}>
                      <Trash2 size={13} />
                    </Button>
                    <Button variant="ghost" className="h-7 px-2" title="Abrir no calendario" onClick={onOpenCalendar}>
                      <CalendarDays size={13} />
                    </Button>
                  </div>
                </div>
              </div>
            )
          )}

          {mixedAgenda.length === 0 && <p className="text-sm text-zinc-500">Nenhum item para o filtro selecionado.</p>}
        </div>
      </section>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-4 xl:row-span-2">
        <div className="mb-3 flex items-center justify-between">
          <div className="inline-flex items-center gap-2">
            <NotebookPen size={15} className="text-zinc-400" />
            <h3 className="text-lg font-semibold">Anotacoes</h3>
          </div>
          <Button className="h-8 px-3" onClick={() => setNoteModal(true)}>
            <Plus size={14} />
          </Button>
        </div>
        <Input className="h-9" placeholder="Pesquisar..." value={noteSearch} onChange={(event) => setNoteSearch(event.target.value)} />
        <div className="mt-2 space-y-1.5 overflow-y-auto pr-1" style={{ maxHeight: "calc(100vh - 15rem)" }}>
          {visibleNotes.map((note) => (
            <button key={note.id} className="w-full rounded-2xl border border-zinc-800 bg-zinc-950/40 p-2 text-left" onClick={() => setNoteDetailId(note.id)}>
              <div className="flex items-center justify-between gap-1">
                <p className="truncate text-sm text-zinc-100">{note.title}</p>
                <div className="flex gap-0.5">
                  <Button variant="ghost" className="h-7 px-2" title="Mover para cima" onClick={(event) => { event.stopPropagation(); moveNote(note.id, "up"); }}>
                    <ArrowUp size={13} />
                  </Button>
                  <Button variant="ghost" className="h-7 px-2" title="Mover para baixo" onClick={(event) => { event.stopPropagation(); moveNote(note.id, "down"); }}>
                    <ArrowDown size={13} />
                  </Button>
                  <Button variant="ghost" className="h-7 px-2" title={note.pinned ? "Desfixar" : "Fixar"} onClick={(event) => { event.stopPropagation(); onUpdateNote(note.id, { pinned: !note.pinned }); }}>
                    {note.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                  </Button>
                  <Button
                    variant="ghost"
                    className="h-7 px-2"
                    title="Editar"
                    onClick={(event) => {
                      event.stopPropagation();
                      setEditingNoteId(note.id);
                      setNoteTitle(note.title);
                      setNoteContent(note.content);
                      setNoteModal(true);
                    }}
                  >
                    <Pencil size={13} />
                  </Button>
                  <Button variant="danger" className="h-7 px-2" title="Excluir" onClick={(event) => { event.stopPropagation(); onDeleteNote(note.id); }}>
                    <Trash2 size={13} />
                  </Button>
                </div>
              </div>
              <p className="mt-1 truncate text-xs text-zinc-500">{note.content}</p>
            </button>
          ))}
          {visibleNotes.length === 0 && <p className="text-sm text-zinc-500">Sem anotacoes.</p>}
        </div>
      </section>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-4">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-base font-semibold">Aguardando</h3>
          <Button className="h-8 px-2" onClick={() => setAwaitingModal(true)}>
            <Plus size={13} />
          </Button>
        </div>
        <div className="space-y-1.5 overflow-y-auto" style={{ maxHeight: "calc(50vh - 6.5rem)" }}>
          {awaiting.slice(0, 5).map((item) => (
            <div key={item.id} className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-2">
              <p className="truncate text-sm text-zinc-100">{item.title}</p>
              <div className="mt-1 flex gap-0.5">
                <Button variant="ghost" className="h-7 px-2" title="Concluir/Reabrir" onClick={() => onUpdateAwaiting(item.id, { status: item.status === "Aguardando" ? "Concluido" : "Aguardando" })}>
                  <ArrowRight size={13} />
                </Button>
                <Button variant="ghost" className="h-7 px-2" title="Editar" onClick={() => {
                  setEditingAwaitingId(item.id);
                  setAwaitingTitle(item.title);
                  setAwaitingDesc(item.description);
                  setAwaitingModal(true);
                }}>
                  <Pencil size={13} />
                </Button>
                <Button variant="ghost" className="h-7 px-2" title="Mover para tarefa" onClick={() => onCreateTask({
                  title: item.title,
                  description: item.description,
                  category: "Administrativo",
                  priority: "Importante",
                  status: "Pendente",
                  dueDate: today,
                })}>
                  <ArrowRight size={13} />
                </Button>
                <Button variant="danger" className="h-7 px-2" title="Excluir" onClick={() => onDeleteAwaiting(item.id)}>
                  <Trash2 size={13} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-4">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-base font-semibold">Prazos</h3>
          <Button
            className="h-8 px-2"
            onClick={() => {
              setEditingDeadlineId(null);
              setDeadlineTitle("");
              setDeadlineDescription("");
              setDeadlineDate(today);
              setDeadlineTime("");
              setDeadlinePriority("Importante");
              setDeadlineModal(true);
            }}
          >
            <Plus size={13} />
          </Button>
        </div>
        <div className="space-y-1.5">
          {orderedDeadlines.map((item) => (
            <div key={item.id} className="rounded-2xl border border-zinc-800 bg-zinc-950/40 px-2 py-1.5">
              <div className="flex items-center justify-between gap-1">
                <p className={`truncate text-sm ${item.status === "Concluido" ? "text-zinc-500 line-through" : "text-zinc-200"}`}>
                  {formatDateBR(item.dueDate)} {item.time ? `- ${item.time}` : ""} - {item.title}
                </p>
                <div className="flex gap-0.5">
                  <Button variant="ghost" className="h-7 px-2" title="Mover para cima" onClick={() => moveDeadline(item.id, "up")}>
                    <ArrowUp size={13} />
                  </Button>
                  <Button variant="ghost" className="h-7 px-2" title="Mover para baixo" onClick={() => moveDeadline(item.id, "down")}>
                    <ArrowDown size={13} />
                  </Button>
                  <Button variant="ghost" className="h-7 px-2" title="Expandir" onClick={() => setExpandedDeadlineId((previous) => (previous === item.id ? null : item.id))}>
                    <Eye size={13} />
                  </Button>
                  <Button
                    variant="ghost"
                    className="h-7 px-2"
                    title="Editar"
                    onClick={() => {
                      setEditingDeadlineId(item.id);
                      setDeadlineTitle(item.title);
                      setDeadlineDescription(item.description);
                      setDeadlineDate(item.dueDate);
                      setDeadlineTime(item.time ?? "");
                      setDeadlinePriority(item.priority);
                      setDeadlineModal(true);
                    }}
                  >
                    <Pencil size={13} />
                  </Button>
                  <Button
                    variant="ghost"
                    className="h-7 px-2"
                    title={item.status === "Concluido" ? "Reabrir" : "Concluir"}
                    onClick={() => onUpdateDeadline(item.id, { status: item.status === "Concluido" ? "EmAberto" : "Concluido" })}
                  >
                    {item.status === "Concluido" ? <ArrowRight size={13} /> : <CheckCircle2 size={13} />}
                  </Button>
                  <Button variant="danger" className="h-7 px-2" title="Excluir" onClick={() => onDeleteDeadline(item.id)}>
                    <Trash2 size={13} />
                  </Button>
                </div>
              </div>
              {expandedDeadlineId === item.id && item.description && <p className="mt-1 text-xs text-zinc-500">{item.description}</p>}
            </div>
          ))}
        </div>
      </section>

      <Modal open={taskModal} onClose={() => setTaskModal(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingTaskId ? "Editar tarefa" : "Criar tarefa"}</h3>
          <Input placeholder="Titulo" value={taskForm.title} onChange={(event) => setTaskForm((prev) => ({ ...prev, title: event.target.value }))} />
          <div className="grid grid-cols-2 gap-3">
            <Select value={taskForm.priority} onChange={(event) => setTaskForm((prev) => ({ ...prev, priority: event.target.value as TaskPriority }))}>
              <option>Critica</option>
              <option>Importante</option>
              <option>Normal</option>
            </Select>
            <Input type="date" value={taskForm.dueDate} onChange={(event) => setTaskForm((prev) => ({ ...prev, dueDate: event.target.value }))} />
          </div>

          <button className="text-sm text-violet-300" onClick={() => setShowTaskAdvanced((previous) => !previous)}>
            {showTaskAdvanced ? "Ocultar avancado" : "Mostrar avancado"}
          </button>

          {showTaskAdvanced && (
            <>
              <Input placeholder="Descricao" value={taskForm.description} onChange={(event) => setTaskForm((prev) => ({ ...prev, description: event.target.value }))} />
              <div className="grid grid-cols-2 gap-3">
                <Input type="time" value={taskForm.time} onChange={(event) => setTaskForm((prev) => ({ ...prev, time: event.target.value }))} />
                <Select
                  value={taskForm.category}
                  onChange={(event) => setTaskForm((prev) => ({ ...prev, category: event.target.value as EventCategory }))}
                >
                  <option>Administrativo</option>
                  <option>Financeiro</option>
                  <option>RH</option>
                  <option>Compras</option>
                  <option>Pessoal</option>
                </Select>
              </div>

              <div className="rounded-2xl border border-zinc-800 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-sm text-zinc-200">Repetir tarefa</p>
                  <button
                    className={`h-6 w-11 rounded-full transition ${taskForm.recurring ? "bg-violet-500" : "bg-zinc-700"}`}
                    onClick={() => setTaskForm((previous) => ({ ...previous, recurring: !previous.recurring }))}
                  >
                    <span
                      className={`block h-5 w-5 rounded-full bg-white transition ${taskForm.recurring ? "translate-x-5" : "translate-x-0.5"}`}
                    />
                  </button>
                </div>

                {taskForm.recurring && (
                  <div className="space-y-2">
                    <Select
                      value={taskForm.repeat}
                      onChange={(event) => setTaskForm((previous) => ({ ...previous, repeat: event.target.value as typeof taskForm.repeat }))}
                    >
                      <option value="daily">Diariamente</option>
                      <option value="weekly">Semanalmente</option>
                      <option value="monthly">Mensalmente</option>
                      <option value="yearly">Anualmente</option>
                      <option value="custom">Personalizado</option>
                    </Select>

                    {taskForm.repeat === "weekly" && (
                      <div className="flex flex-wrap gap-1">
                        {[
                          { label: "Seg", value: 1 },
                          { label: "Ter", value: 2 },
                          { label: "Qua", value: 3 },
                          { label: "Qui", value: 4 },
                          { label: "Sex", value: 5 },
                          { label: "Sab", value: 6 },
                          { label: "Dom", value: 7 },
                        ].map((day) => (
                          <button
                            key={day.value}
                            className={`rounded-lg border px-2 py-1 text-xs ${
                              taskForm.weeklyDays.includes(day.value) ? "border-violet-500 bg-violet-500/20" : "border-zinc-700"
                            }`}
                            onClick={() =>
                              setTaskForm((previous) => ({
                                ...previous,
                                weeklyDays: previous.weeklyDays.includes(day.value)
                                  ? previous.weeklyDays.filter((value) => value !== day.value)
                                  : [...previous.weeklyDays, day.value],
                              }))
                            }
                          >
                            {day.label}
                          </button>
                        ))}
                      </div>
                    )}

                    {taskForm.repeat === "monthly" && (
                      <Select
                        value={taskForm.monthlyMode}
                        onChange={(event) => setTaskForm((previous) => ({ ...previous, monthlyMode: event.target.value as typeof taskForm.monthlyMode }))}
                      >
                        <option value="dayOfMonth">Mesmo dia do mes</option>
                        <option value="dayOfWeek">Mesmo dia da semana</option>
                      </Select>
                    )}

                    {taskForm.repeat === "custom" && (
                      <div className="grid grid-cols-2 gap-2">
                        <Input
                          type="number"
                          min={1}
                          value={taskForm.customInterval}
                          onChange={(event) => setTaskForm((previous) => ({ ...previous, customInterval: Number(event.target.value) || 1 }))}
                        />
                        <Select
                          value={taskForm.customUnit}
                          onChange={(event) => setTaskForm((previous) => ({ ...previous, customUnit: event.target.value as typeof taskForm.customUnit }))}
                        >
                          <option value="days">Dias</option>
                          <option value="weeks">Semanas</option>
                          <option value="months">Meses</option>
                          <option value="years">Anos</option>
                        </Select>
                      </div>
                    )}

                    <Select
                      value={taskForm.endType}
                      onChange={(event) => setTaskForm((previous) => ({ ...previous, endType: event.target.value as typeof taskForm.endType }))}
                    >
                      <option value="never">Nunca termina</option>
                      <option value="untilDate">Ate uma data</option>
                      <option value="occurrences">Quantidade de repeticoes</option>
                    </Select>

                    {taskForm.endType === "untilDate" && (
                      <Input type="date" value={taskForm.untilDate} onChange={(event) => setTaskForm((previous) => ({ ...previous, untilDate: event.target.value }))} />
                    )}
                    {taskForm.endType === "occurrences" && (
                      <Input
                        type="number"
                        min={1}
                        value={taskForm.occurrences}
                        onChange={(event) => setTaskForm((previous) => ({ ...previous, occurrences: Number(event.target.value) || 1 }))}
                      />
                    )}
                  </div>
                )}
              </div>
            </>
          )}

          <Button className="w-full" onClick={() => {
            if (!taskForm.title.trim()) return;
            const payload = {
              title: taskForm.title,
              description: taskForm.description,
              category: taskForm.category,
              priority: taskForm.priority,
              dueDate: taskForm.dueDate,
              time: taskForm.time || undefined,
              recurrence: taskForm.recurring
                ? {
                    enabled: true,
                    repeat: taskForm.repeat,
                    weeklyDays: taskForm.weeklyDays,
                    monthlyMode: taskForm.monthlyMode,
                    customInterval: taskForm.customInterval,
                    customUnit: taskForm.customUnit,
                    endType: taskForm.endType,
                    untilDate: taskForm.endType === "untilDate" ? taskForm.untilDate || null : null,
                    occurrences: taskForm.endType === "occurrences" ? taskForm.occurrences : null,
                  }
                : undefined,
            };

            if (editingTaskId) {
              const current = tasks.find((task) => task.id === editingTaskId);
              if (current?.recurrence?.enabled) {
                const applySeries = window.confirm("Editar toda a serie? Cancelar aplica somente esta ocorrencia.");
                if (applySeries) {
                  onUpdateTask(editingTaskId, payload);
                } else {
                  onCreateTask({ ...payload, recurrence: undefined, status: current.status });
                }
              } else {
                onUpdateTask(editingTaskId, payload);
              }
            } else {
              onCreateTask({
                ...payload,
                status: "Pendente",
              });
            }
            setTaskModal(false);
            setEditingTaskId(null);
            setTaskForm(defaultTask);
            setShowTaskAdvanced(false);
          }}>Salvar tarefa</Button>
        </div>
      </Modal>

      <Modal open={awaitingModal} onClose={() => setAwaitingModal(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingAwaitingId ? "Editar aguardando" : "Novo aguardando"}</h3>
          <Input placeholder="Titulo" value={awaitingTitle} onChange={(event) => setAwaitingTitle(event.target.value)} />
          <Input placeholder="Descricao" value={awaitingDesc} onChange={(event) => setAwaitingDesc(event.target.value)} />
          <Button className="w-full" onClick={() => {
            if (!awaitingTitle.trim()) return;
            if (editingAwaitingId) {
              onUpdateAwaiting(editingAwaitingId, { title: awaitingTitle, description: awaitingDesc });
            } else {
              onCreateAwaiting({ title: awaitingTitle, description: awaitingDesc, status: "Aguardando" });
            }
            setAwaitingModal(false);
            setAwaitingTitle("");
            setAwaitingDesc("");
            setEditingAwaitingId(null);
          }}>Salvar</Button>
        </div>
      </Modal>

      <Modal open={deadlineModal} onClose={() => setDeadlineModal(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingDeadlineId ? "Editar prazo" : "Novo prazo"}</h3>
          <Input placeholder="Titulo" value={deadlineTitle} onChange={(event) => setDeadlineTitle(event.target.value)} />
          <Input placeholder="Descricao" value={deadlineDescription} onChange={(event) => setDeadlineDescription(event.target.value)} />
          <div className="grid grid-cols-2 gap-3">
            <Input type="date" value={deadlineDate} onChange={(event) => setDeadlineDate(event.target.value)} />
            <Input type="time" value={deadlineTime} onChange={(event) => setDeadlineTime(event.target.value)} />
          </div>
          <Select value={deadlinePriority} onChange={(event) => setDeadlinePriority(event.target.value as TaskPriority)}>
            <option>Critica</option>
            <option>Importante</option>
            <option>Normal</option>
          </Select>
          <Button className="w-full" onClick={() => {
            if (!deadlineTitle.trim()) return;
            if (editingDeadlineId) {
              onUpdateDeadline(editingDeadlineId, {
                title: deadlineTitle,
                description: deadlineDescription,
                dueDate: deadlineDate,
                time: deadlineTime,
                priority: deadlinePriority,
              });
            } else {
              onCreateDeadline({
                title: deadlineTitle,
                description: deadlineDescription,
                dueDate: deadlineDate,
                time: deadlineTime,
                priority: deadlinePriority,
                status: "EmAberto",
                notesLinked: [],
              });
            }
            setDeadlineModal(false);
            setEditingDeadlineId(null);
            setDeadlineTitle("");
            setDeadlineDescription("");
            setDeadlineTime("");
            setDeadlinePriority("Importante");
          }}>Salvar prazo</Button>
        </div>
      </Modal>

      <Modal open={noteModal} onClose={() => setNoteModal(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingNoteId ? "Editar anotacao" : "Nova anotacao"}</h3>
          <Input placeholder="Titulo" value={noteTitle} onChange={(event) => setNoteTitle(event.target.value)} />
          <Input placeholder="Conteudo" value={noteContent} onChange={(event) => setNoteContent(event.target.value)} />
          <Button className="w-full" onClick={() => {
            if (!noteTitle.trim()) return;
            if (editingNoteId) {
              onUpdateNote(editingNoteId, { title: noteTitle, content: noteContent });
            } else {
              onCreateNote({
                title: noteTitle,
                content: noteContent,
                category: "Geral",
                tags: [],
                pinned: false,
                favorite: false,
                linkedType: "none",
                linkedId: null,
              });
            }
            setNoteModal(false);
            setNoteTitle("");
            setNoteContent("");
            setEditingNoteId(null);
          }}>Salvar anotacao</Button>
        </div>
      </Modal>

      <Modal open={eventEditOpen} onClose={() => setEventEditOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Editar evento</h3>
          <Input
            placeholder="Titulo"
            value={editingEvent?.title ?? ""}
            onChange={(event) => setEditingEvent((previous) => (previous ? { ...previous, title: event.target.value } : previous))}
          />
          <Input
            type="date"
            value={editingEvent?.date ?? today}
            onChange={(event) => setEditingEvent((previous) => (previous ? { ...previous, date: event.target.value } : previous))}
          />
          <Input
            type="time"
            value={editingEvent?.time ?? "09:00"}
            onChange={(event) => setEditingEvent((previous) => (previous ? { ...previous, time: event.target.value } : previous))}
          />
          <Button
            className="w-full"
            onClick={() => {
              if (!editingEvent) return;
              onUpdateEvent(editingEvent.id, {
                title: editingEvent.title,
                date: editingEvent.date,
                time: editingEvent.time,
              });
              setEventEditOpen(false);
            }}
          >
            Salvar evento
          </Button>
        </div>
      </Modal>

      <Modal open={eventDetailOpen} onClose={() => setEventDetailOpen(false)}>
        <div className="space-y-2">
          <h3 className="text-lg font-semibold">Detalhes do evento</h3>
          <p className="text-sm text-zinc-200">{editingEvent?.title}</p>
          <p className="text-xs text-zinc-500">{editingEvent ? `${formatDateBR(editingEvent.date)} ${editingEvent.time}` : ""}</p>
          <p className="text-xs text-zinc-500">{editingEvent?.description || "Sem descricao"}</p>
        </div>
      </Modal>

      <Modal open={Boolean(noteDetail)} onClose={() => setNoteDetailId(null)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{noteDetail?.title}</h3>
          <p className="text-sm text-zinc-300">{noteDetail?.content}</p>
        </div>
      </Modal>
    </div>
  );
}
