import { useEffect, useMemo, useState, type DragEvent } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from "lucide-react";
import { Button } from "../components/ui/button";
import { TaskItemRow } from "../components/tasks/task-item-row";
import { formatDateBR } from "../lib/date-format";
import { Input } from "../components/ui/input";
import { Modal } from "../components/ui/modal";
import { Select } from "../components/ui/select";
import { getTaskOccurrencesInRange } from "../lib/task-recurrence";
import { taskPriorityColor, taskPriorityRank } from "../lib/task-priority";
import type { DeadlineItem, EventCategory, EventItem, NoteItem, TaskItem, TaskPriority } from "../types";

const categories: EventCategory[] = ["Administrativo", "Financeiro", "RH", "Compras", "Pessoal"];

interface CalendarPageProps {
  events: EventItem[];
  tasks: TaskItem[];
  notes: NoteItem[];
  deadlines: DeadlineItem[];
  onCreateEvent: (event: Omit<EventItem, "id" | "userId" | "spaceId">) => void;
  onUpdateEvent: (eventId: string, event: Partial<EventItem>) => void;
  onDeleteEvent: (eventId: string) => void;
  onCreateTask: (task: Omit<TaskItem, "id" | "userId" | "spaceId">) => void;
  onToggleTask: (taskId: string) => void;
  onUpdateTask: (taskId: string, task: Partial<TaskItem>) => void;
  focusDate?: string;
  focusMode?: "events" | "agenda";
  focusToken?: number;
}

const defaultEventForm = {
  title: "",
  description: "",
  date: new Date().toISOString().slice(0, 10),
  time: "09:00",
  category: "Administrativo" as EventCategory,
  color: "#8B5CF6",
};

const defaultQuickAdd = {
  type: "task" as "task" | "event",
  title: "",
};

function priorityRank(priority: TaskPriority) {
  return taskPriorityRank(priority) === 2 ? 4 : taskPriorityRank(priority);
}

function colorToImportance(color: string) {
  const hex = color.replace("#", "");
  if (hex.length !== 6) return "Normal" as const;

  const red = parseInt(hex.slice(0, 2), 16);
  const green = parseInt(hex.slice(2, 4), 16);
  const blue = parseInt(hex.slice(4, 6), 16);

  const max = Math.max(red, green, blue);
  const min = Math.min(red, green, blue);
  const diff = max - min;
  let hue = 0;

  if (diff !== 0) {
    if (max === red) hue = ((green - blue) / diff) % 6;
    else if (max === green) hue = (blue - red) / diff + 2;
    else hue = (red - green) / diff + 4;
    hue = Math.round(hue * 60);
    if (hue < 0) hue += 360;
  }

  if (hue <= 16 || hue >= 345) return "Critica" as const;
  if (hue >= 22 && hue <= 58) return "Importante" as const;
  return "Normal" as const;
}

function eventImportance(event: EventItem) {
  const text = `${event.title} ${event.description}`.toLowerCase();
  if (text.includes("crit") || text.includes("urgen") || colorToImportance(event.color) === "Critica") {
    return "Critica" as const;
  }
  if (
    text.includes("import") ||
    text.includes("prior") ||
    event.category === "Financeiro" ||
    event.category === "RH" ||
    colorToImportance(event.color) === "Importante"
  ) {
    return "Importante" as const;
  }
  return "Normal" as const;
}

function eventRank(event: EventItem) {
  const importance = eventImportance(event);
  if (importance === "Critica") return 2;
  if (importance === "Importante") return 3;
  return 5;
}

function eventBackground(color: string) {
  return `${color}CC`;
}

function createDateFromIso(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, (month ?? 1) - 1, day ?? 1);
}

export function CalendarPage({
  events,
  tasks,
  notes,
  deadlines,
  onCreateEvent,
  onUpdateEvent,
  onDeleteEvent,
  onCreateTask,
  onToggleTask,
  onUpdateTask,
  focusDate,
  focusMode,
  focusToken,
}: CalendarPageProps) {
  const [month, setMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const todayIso = new Date().toISOString().slice(0, 10);

  const [eventModalOpen, setEventModalOpen] = useState(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [eventForm, setEventForm] = useState(defaultEventForm);

  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [quickAddDate, setQuickAddDate] = useState(new Date().toISOString().slice(0, 10));
  const [quickAddForm, setQuickAddForm] = useState(defaultQuickAdd);

  const [detailOpen, setDetailOpen] = useState(false);
  const [manualOrderByDate, setManualOrderByDate] = useState<Record<string, string[]>>({});

  useEffect(() => {
    if (!focusDate || !focusToken) return;
    setSelectedDate(focusDate);
    setMonth(createDateFromIso(focusDate));
    setDetailOpen(true);
  }, [focusDate, focusToken]);

  const monthGrid = useMemo(() => {
    const first = new Date(month.getFullYear(), month.getMonth(), 1);
    const start = new Date(first);
    start.setDate(first.getDate() - first.getDay());
    return Array.from({ length: 42 }, (_, index) => {
      const date = new Date(start);
      date.setDate(start.getDate() + index);
      return date;
    });
  }, [month]);

  const taskOccurrencesByDate = useMemo(() => {
    const rangeStart = monthGrid[0]?.toISOString().slice(0, 10) ?? selectedDate;
    const rangeEnd = monthGrid[monthGrid.length - 1]?.toISOString().slice(0, 10) ?? selectedDate;
    const map = new Map<string, Array<{ id: string; task: TaskItem }>>();

    for (const task of tasks) {
      const occurrences = getTaskOccurrencesInRange(task, rangeStart, rangeEnd);
      for (const occurrence of occurrences) {
        const current = map.get(occurrence.date) ?? [];
        current.push({ id: occurrence.id, task: occurrence.task });
        map.set(occurrence.date, current);
      }
    }

    return map;
  }, [monthGrid, selectedDate, tasks]);

  const selectedEvents = events
    .filter((event) => event.date === selectedDate)
    .sort((left, right) => left.time.localeCompare(right.time));

  const selectedDeadlines = deadlines
    .filter((item) => item.dueDate === selectedDate)
    .sort((left, right) => taskPriorityRank(left.priority) - taskPriorityRank(right.priority));

  const selectedTasks = (taskOccurrencesByDate.get(selectedDate) ?? [])
    .map((item) => item.task)
    .sort((left, right) => priorityRank(left.priority) - priorityRank(right.priority));

  const selectedDayItemsBase = useMemo(() => {
    const taskItems = selectedTasks.map((task) => ({
      id: task.id,
      kind: "task" as const,
      title: task.title,
      description: task.description,
      priority: task.priority,
      status: task.status,
      rank: task.status === "Concluida" ? 6 : priorityRank(task.priority),
      time: "",
      task,
    }));

    const eventItems = selectedEvents.map((event) => ({
      id: event.id,
      kind: "event" as const,
      title: event.title,
      description: event.description,
      priority: eventImportance(event),
      status: "Agendado",
      rank: eventRank(event),
      time: event.time,
      color: event.color,
      event,
    }));

    const deadlineItems = selectedDeadlines.map((deadline) => ({
      id: deadline.id,
      kind: "deadline" as const,
      title: deadline.title,
      description: deadline.description,
      priority: deadline.priority,
      status: deadline.status,
      rank: taskPriorityRank(deadline.priority),
      time: deadline.time ?? "",
      color: taskPriorityColor(deadline.priority),
      deadline,
    }));

    return [...taskItems, ...eventItems, ...deadlineItems].sort((left, right) => {
      if (left.rank !== right.rank) return left.rank - right.rank;
      return (left.time ?? "").localeCompare(right.time ?? "");
    });
  }, [selectedTasks, selectedEvents, selectedDeadlines]);

  const selectedDayItems = useMemo(() => {
    const manual = manualOrderByDate[selectedDate];
    if (!manual || manual.length === 0) {
      return selectedDayItemsBase;
    }

    const itemMap = new Map(selectedDayItemsBase.map((item) => [item.id, item]));
    const ordered = manual.map((id) => itemMap.get(id)).filter(Boolean) as typeof selectedDayItemsBase;
    const remaining = selectedDayItemsBase.filter((item) => !manual.includes(item.id));
    return [...ordered, ...remaining];
  }, [manualOrderByDate, selectedDate, selectedDayItemsBase]);

  const moveItemInDay = (date: string, itemId: string, direction: "up" | "down", fallbackItems: Array<{ id: string }>) => {
    setManualOrderByDate((previous) => {
      const base = previous[date]?.filter((id) => fallbackItems.some((item) => item.id === id)) ?? fallbackItems.map((item) => item.id);
      const currentIndex = base.indexOf(itemId);
      if (currentIndex === -1) {
        return previous;
      }

      const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
      if (targetIndex < 0 || targetIndex >= base.length) {
        return previous;
      }

      const next = [...base];
      const [moved] = next.splice(currentIndex, 1);
      next.splice(targetIndex, 0, moved);
      return { ...previous, [date]: next };
    });
  };

  const openQuickAdd = (date: string) => {
    setQuickAddDate(date);
    setQuickAddForm(defaultQuickAdd);
    setQuickAddOpen(true);
  };

  const saveQuickAdd = () => {
    if (!quickAddForm.title.trim()) return;

    if (quickAddForm.type === "task") {
      onCreateTask({
        title: quickAddForm.title,
        description: "",
        category: "Administrativo",
        priority: "Normal",
        status: "Pendente",
        dueDate: quickAddDate,
      });
    } else {
      onCreateEvent({
        title: quickAddForm.title,
        description: "",
        date: quickAddDate,
        time: "09:00",
        category: "Administrativo",
        color: "#8B5CF6",
      });
    }

    setQuickAddOpen(false);
  };

  const saveEvent = () => {
    if (!eventForm.title.trim()) return;
    if (editingEventId) {
      onUpdateEvent(editingEventId, eventForm);
    } else {
      onCreateEvent(eventForm);
    }
    setEventModalOpen(false);
    setEditingEventId(null);
    setEventForm(defaultEventForm);
  };

  const openCreateEvent = () => {
    setEditingEventId(null);
    setEventForm({ ...defaultEventForm, date: selectedDate });
    setEventModalOpen(true);
  };

  const handleDropItem = (date: string, event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const payload = event.dataTransfer.getData("text/plain");
    if (!payload) return;

    const [type, id] = payload.split(":");
    if (!type || !id) return;

    if (type === "task") {
      onUpdateTask(id, { dueDate: date });
      return;
    }

    if (type === "event") {
      onUpdateEvent(id, { date });
    }
  };

  return (
    <div className="space-y-3 px-2 md:px-3">
      <div className="flex flex-wrap items-center justify-between gap-3 px-1">
        <div>
          <h2 className="text-3xl font-semibold">Calendario operacional</h2>
          <p className="text-zinc-500">Visualizacao mensal com tarefas e eventos no mesmo fluxo.</p>
          {focusMode === "events" && focusDate && <p className="mt-2 text-sm text-violet-300">Filtro rapido: eventos de hoje</p>}
          {focusMode === "agenda" && focusDate && <p className="mt-2 text-sm text-violet-300">Agenda detalhada de hoje aberta</p>}
        </div>
        <Button className="mr-1" onClick={openCreateEvent}>
          Novo evento
        </Button>
      </div>

      <section className="rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-3">
        <div className="mb-3 flex items-center justify-between">
          <Button
            variant="secondary"
            className="h-10 border-[var(--surface-border)] bg-[var(--surface-soft)] text-[var(--app-text)] hover:bg-zinc-800/70"
            onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}
          >
            <ChevronLeft size={16} /> Mes anterior
          </Button>
          <p className="text-lg font-medium">{month.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</p>
          <Button
            variant="secondary"
            className="h-10 border-[var(--surface-border)] bg-[var(--surface-soft)] text-[var(--app-text)] hover:bg-zinc-800/70"
            onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}
          >
            Proximo mes <ChevronRight size={16} />
          </Button>
        </div>

        <div className="grid grid-cols-7 border-b border-zinc-800 pb-2 text-center text-xs text-zinc-500">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"].map((day) => (
            <p key={day}>{day}</p>
          ))}
        </div>

        <div className="mt-2 grid grid-cols-7 gap-1">
          {monthGrid.map((date) => {
            const dateKey = date.toISOString().slice(0, 10);
            const isCurrent = date.getMonth() === month.getMonth();
            const isToday = dateKey === todayIso;

            const dayTasks = (taskOccurrencesByDate.get(dateKey) ?? []).map((item) => ({
              id: item.id,
              kind: "task" as const,
              title: item.task.title,
              rank: item.task.status === "Concluida" ? 6 : priorityRank(item.task.priority),
              priority: item.task.priority,
              status: item.task.status,
              task: item.task,
            }));

            const dayEvents = events
              .filter((event) => event.date === dateKey)
              .map((event) => ({
                id: event.id,
                kind: "event" as const,
                title: `${event.time} ${event.title}`,
                rank: eventRank(event),
                priority: eventImportance(event),
                color: event.color,
                event,
              }));

            const dayDeadlines = deadlines
              .filter((item) => item.dueDate === dateKey)
              .map((item) => ({
                id: item.id,
                kind: "deadline" as const,
                title: `${item.time ?? ""} ${item.title}`.trim(),
                rank: taskPriorityRank(item.priority),
                priority: item.priority,
                color: taskPriorityColor(item.priority),
              }));

            const dayItemsBase = [...dayTasks, ...dayEvents, ...dayDeadlines].sort((left, right) => left.rank - right.rank);
            const dayManual = manualOrderByDate[dateKey];
            const dayItems = dayManual
              ? [
                  ...dayManual
                    .map((id) => dayItemsBase.find((item) => item.id === id))
                    .filter((item): item is (typeof dayItemsBase)[number] => Boolean(item)),
                  ...dayItemsBase.filter((item) => !dayManual.includes(item.id)),
                ]
              : dayItemsBase;
            const visibleItems = dayItems.slice(0, 7);

            return (
              <div
                key={dateKey}
                className={`min-h-[180px] rounded-2xl border p-2 transition ${
                  selectedDate === dateKey ? "border-violet-500 bg-violet-500/10" : "border-zinc-800"
                } ${isCurrent ? "text-zinc-100" : "text-zinc-500 opacity-55"}`}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => handleDropItem(dateKey, event)}
                onClick={() => {
                  setSelectedDate(dateKey);
                  openQuickAdd(dateKey);
                }}
              >
                <div className="mb-2 flex items-center justify-between">
                  <button
                    className="rounded-full"
                    onClick={(event) => {
                      event.stopPropagation();
                      setSelectedDate(dateKey);
                      setDetailOpen(true);
                    }}
                  >
                    {isToday ? (
                      <span className="grid h-7 w-7 place-items-center rounded-full bg-violet-500 text-xs font-semibold text-white">
                        {date.getDate()}
                      </span>
                    ) : (
                      <span className="text-sm font-medium">{date.getDate()}</span>
                    )}
                  </button>
                </div>
                <div className="space-y-0.5">
                  {visibleItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex min-h-5 items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] leading-tight transition hover:brightness-110"
                      style={
                        item.kind === "task"
                          ? {
                              backgroundColor: "var(--surface-soft)",
                              boxShadow: `inset 2px 0 0 ${taskPriorityColor(item.priority)}`,
                            }
                          : {
                              backgroundColor: eventBackground(item.color),
                              color: "#FFFFFF",
                            }
                      }
                      onClick={(event) => {
                        event.stopPropagation();
                        setSelectedDate(dateKey);
                        setDetailOpen(true);
                      }}
                      draggable
                      onDragStart={(event) => {
                        event.dataTransfer.setData("text/plain", `${item.kind}:${item.id}`);
                      }}
                    >
                      {item.kind === "task" ? (
                        <button
                          className={`grid h-7 w-7 shrink-0 place-items-center text-lg ${
                            item.status === "Concluida" ? "text-emerald-300" : "text-zinc-300"
                          }`}
                          onClick={(event) => {
                            event.stopPropagation();
                            onToggleTask(item.task.id);
                          }}
                        >
                          {item.status === "Concluida" ? "✓" : "○"}
                        </button>
                      ) : (
                        <span className="w-3 shrink-0 text-[10px] text-white">●</span>
                      )}
                      <span
                        className={`min-w-0 flex-1 truncate ${
                          item.kind === "task" && item.status === "Concluida"
                            ? "line-through text-zinc-500"
                            : item.kind === "event" || item.kind === "deadline"
                              ? "text-white"
                              : "text-zinc-200"
                        }`}
                      >
                        {item.title}
                      </span>
                    </div>
                  ))}

                  {dayItems.length > 7 && (
                    <button
                      className="w-full rounded-md bg-zinc-900/45 px-1.5 py-0.5 text-left text-[11px] text-zinc-500 transition hover:text-zinc-300"
                      onClick={(event) => {
                        event.stopPropagation();
                        setSelectedDate(dateKey);
                        setDetailOpen(true);
                      }}
                    >
                      +{dayItems.length - 7} itens
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <Modal open={detailOpen} onClose={() => setDetailOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Detalhes de {selectedDate}</h3>
          <p className="text-xs text-zinc-500">{formatDateBR(selectedDate)}</p>
          <p className="text-sm text-zinc-500">Tarefas e eventos em ordem de prioridade e urgencia.</p>

          <div className="max-h-[60vh] space-y-2 overflow-y-auto pr-1">
            {selectedDayItems.map((item, index) => (
              <div
                key={`${item.kind}-${item.id}`}
                className="rounded-2xl border border-zinc-800 bg-zinc-950/50 p-3"
                style={item.kind === "event" || item.kind === "deadline" ? { backgroundColor: `${item.color ?? "#8B5CF6"}CC` } : undefined}
              >
                {item.kind === "task" ? (
                  <TaskItemRow
                    task={item.task}
                    onToggle={onToggleTask}
                    onEdit={(task) => onUpdateTask(task.id, { title: task.title })}
                    onMoveUp={() => moveItemInDay(selectedDate, item.id, "up", selectedDayItemsBase)}
                    onMoveDown={() => moveItemInDay(selectedDate, item.id, "down", selectedDayItemsBase)}
                  />
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <p className="text-sm text-white">{item.title}</p>
                    <div className="ml-auto flex items-center gap-1">
                      <button
                        className="rounded-md border border-zinc-700 p-1 text-zinc-400 transition hover:text-zinc-100 disabled:opacity-30"
                        onClick={() => moveItemInDay(selectedDate, item.id, "up", selectedDayItemsBase)}
                        disabled={index === 0}
                        title="Mover para cima"
                      >
                        <ChevronUp size={12} />
                      </button>
                      <button
                        className="rounded-md border border-zinc-700 p-1 text-zinc-400 transition hover:text-zinc-100 disabled:opacity-30"
                        onClick={() => moveItemInDay(selectedDate, item.id, "down", selectedDayItemsBase)}
                        disabled={index === selectedDayItems.length - 1}
                        title="Mover para baixo"
                      >
                        <ChevronDown size={12} />
                      </button>
                    </div>
                  </div>
                )}

                <p className={`mt-1 text-xs ${item.kind === "task" ? "text-zinc-500" : "text-white/80"}`}>Descricao: {item.description || "Sem descricao"}</p>
                <p className={`text-xs ${item.kind === "task" ? "text-zinc-500" : "text-white/80"}`}>Prioridade: {item.priority}</p>
                <p className={`text-xs ${item.kind === "task" ? "text-zinc-500" : "text-white/80"}`}>Status: {item.status}</p>
                <p className={`text-xs ${item.kind === "task" ? "text-zinc-500" : "text-white/80"}`}>
                  Anotacoes vinculadas: {notes.filter((note) => note.linkedType === item.kind && note.linkedId === item.id).length}
                </p>

                {item.kind === "event" && item.event && (
                  <div className="mt-3 flex gap-2">
                    <Button
                      variant="ghost"
                      className="h-8 px-3"
                      onClick={() => {
                        setEditingEventId(item.event.id);
                        setEventForm({
                          title: item.event.title,
                          description: item.event.description,
                          date: item.event.date,
                          time: item.event.time,
                          category: item.event.category,
                          color: item.event.color,
                        });
                        setEventModalOpen(true);
                      }}
                    >
                      Editar
                    </Button>
                    <Button variant="danger" className="h-8 px-3" onClick={() => onDeleteEvent(item.event.id)}>
                      Excluir
                    </Button>
                  </div>
                )}
              </div>
            ))}
            {selectedDayItems.length === 0 && <p className="text-sm text-zinc-500">Sem itens nesta data.</p>}
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" className="flex-1" onClick={() => openQuickAdd(selectedDate)}>
              Adicionar item
            </Button>
            <Button className="flex-1" onClick={() => {
              setDetailOpen(false);
              openCreateEvent();
            }}>
              Novo evento
            </Button>
          </div>
        </div>
      </Modal>

      <Modal open={quickAddOpen} onClose={() => setQuickAddOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Adicionar item</h3>
          <p className="text-sm text-zinc-500">Data: {formatDateBR(quickAddDate)}</p>

          <div className="grid grid-cols-2 gap-2">
            <button
              className={`rounded-2xl border px-3 py-2 text-sm ${
                quickAddForm.type === "task" ? "border-violet-500 bg-violet-500/10 text-zinc-100" : "border-zinc-700 text-zinc-400"
              }`}
              onClick={() => setQuickAddForm((previous) => ({ ...previous, type: "task" }))}
            >
              Tarefa
            </button>
            <button
              className={`rounded-2xl border px-3 py-2 text-sm ${
                quickAddForm.type === "event" ? "border-violet-500 bg-violet-500/10 text-zinc-100" : "border-zinc-700 text-zinc-400"
              }`}
              onClick={() => setQuickAddForm((previous) => ({ ...previous, type: "event" }))}
            >
              Evento
            </button>
          </div>

          <Input
            placeholder="Titulo"
            value={quickAddForm.title}
            onChange={(event) => setQuickAddForm((previous) => ({ ...previous, title: event.target.value }))}
          />
          <Input type="date" value={quickAddDate} onChange={(event) => setQuickAddDate(event.target.value)} />

          <Button className="w-full" onClick={saveQuickAdd}>
            Salvar
          </Button>
        </div>
      </Modal>

      <Modal open={eventModalOpen} onClose={() => setEventModalOpen(false)}>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{editingEventId ? "Editar evento" : "Novo evento"}</h3>
          <Input
            placeholder="Titulo"
            value={eventForm.title}
            onChange={(event) => setEventForm((previous) => ({ ...previous, title: event.target.value }))}
          />
          <Input
            placeholder="Descricao"
            value={eventForm.description}
            onChange={(event) => setEventForm((previous) => ({ ...previous, description: event.target.value }))}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input
              type="date"
              value={eventForm.date}
              onChange={(event) => setEventForm((previous) => ({ ...previous, date: event.target.value }))}
            />
            <Input
              type="time"
              value={eventForm.time}
              onChange={(event) => setEventForm((previous) => ({ ...previous, time: event.target.value }))}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Select
              value={eventForm.category}
              onChange={(event) => setEventForm((previous) => ({ ...previous, category: event.target.value as EventCategory }))}
            >
              {categories.map((category) => (
                <option key={category}>{category}</option>
              ))}
            </Select>
            <Input
              type="color"
              value={eventForm.color}
              onChange={(event) => setEventForm((previous) => ({ ...previous, color: event.target.value }))}
            />
          </div>
          <Button className="w-full" onClick={saveEvent}>
            Salvar evento
          </Button>
        </div>
      </Modal>
    </div>
  );
}
