import type { AwaitingItem, DeadlineItem, EventItem, NoteItem, RunnoState, Space, TaskItem } from "../types";

export function createInitialState(_userId: string): RunnoState {
  const spaces: Space[] = [];
  const events: EventItem[] = [];
  const tasks: TaskItem[] = [];
  const awaiting: AwaitingItem[] = [];
  const deadlines: DeadlineItem[] = [];
  const notes: NoteItem[] = [];

  return {
    spaces,
    events,
    tasks,
    awaiting,
    deadlines,
    notes,
    currentSpaceId: null,
  };
}

export function toDateInput(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}
