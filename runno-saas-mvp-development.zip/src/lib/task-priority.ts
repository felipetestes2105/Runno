import type { TaskPriority } from "../types";

export function taskPriorityRank(priority: TaskPriority) {
  if (priority === "Critica") return 0;
  if (priority === "Importante") return 1;
  return 2;
}

export function taskPriorityColor(priority: TaskPriority) {
  if (priority === "Critica") return "#EF4444";
  if (priority === "Importante") return "#F59E0B";
  return "#3B82F6";
}
