import type { TaskItem } from "../types";

interface TaskOccurrence {
  id: string;
  sourceTaskId: string;
  date: string;
  task: TaskItem;
}

function parseDate(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, (month ?? 1) - 1, day ?? 1);
}

function toIso(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

function startOfDay(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function daysBetween(start: Date, end: Date) {
  const ms = startOfDay(end).getTime() - startOfDay(start).getTime();
  return Math.floor(ms / (24 * 60 * 60 * 1000));
}

function weeksBetween(start: Date, end: Date) {
  return Math.floor(daysBetween(start, end) / 7);
}

function monthsBetween(start: Date, end: Date) {
  return (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
}

function nthWeekdayInMonth(date: Date) {
  return Math.ceil(date.getDate() / 7);
}

function matchesRecurrence(task: TaskItem, candidate: Date, startDate: Date) {
  const recurrence = task.recurrence;
  if (!recurrence || !recurrence.enabled) {
    return toIso(candidate) === task.dueDate;
  }

  const diffDays = daysBetween(startDate, candidate);
  if (diffDays < 0) return false;

  if (recurrence.repeat === "daily") {
    return true;
  }

  if (recurrence.repeat === "weekly") {
    const currentDay = candidate.getDay();
    const normalized = currentDay === 0 ? 7 : currentDay;
    const days = recurrence.weeklyDays.length ? recurrence.weeklyDays : [startDate.getDay() === 0 ? 7 : startDate.getDay()];
    return days.includes(normalized);
  }

  if (recurrence.repeat === "monthly") {
    if (recurrence.monthlyMode === "dayOfWeek") {
      return (
        candidate.getDay() === startDate.getDay() &&
        nthWeekdayInMonth(candidate) === nthWeekdayInMonth(startDate)
      );
    }
    return candidate.getDate() === startDate.getDate();
  }

  if (recurrence.repeat === "yearly") {
    return candidate.getDate() === startDate.getDate() && candidate.getMonth() === startDate.getMonth();
  }

  const interval = Math.max(1, recurrence.customInterval || 1);
  const unit = recurrence.customUnit;

  if (unit === "days") {
    return diffDays % interval === 0;
  }

  if (unit === "weeks") {
    return weeksBetween(startDate, candidate) % interval === 0 && candidate.getDay() === startDate.getDay();
  }

  if (unit === "months") {
    return monthsBetween(startDate, candidate) % interval === 0 && candidate.getDate() === startDate.getDate();
  }

  return (
    (candidate.getFullYear() - startDate.getFullYear()) % interval === 0 &&
    candidate.getMonth() === startDate.getMonth() &&
    candidate.getDate() === startDate.getDate()
  );
}

export function getTaskOccurrencesInRange(task: TaskItem, start: string, end: string) {
  const startDate = parseDate(task.dueDate);
  const rangeEnd = parseDate(end);
  const recurrence = task.recurrence;

  if (!recurrence || !recurrence.enabled) {
    if (task.dueDate >= start && task.dueDate <= end) {
      return [{ id: task.id, sourceTaskId: task.id, date: task.dueDate, task } satisfies TaskOccurrence];
    }
    return [] as TaskOccurrence[];
  }

  const untilDate = recurrence.endType === "untilDate" && recurrence.untilDate ? parseDate(recurrence.untilDate) : null;
  const maxOccurrences = recurrence.endType === "occurrences" && recurrence.occurrences ? recurrence.occurrences : null;

  const limitEnd = untilDate && untilDate < rangeEnd ? untilDate : rangeEnd;
  const cursor = new Date(startDate);
  let count = 0;
  const occurrences: TaskOccurrence[] = [];

  while (cursor <= limitEnd) {
    if (matchesRecurrence(task, cursor, startDate)) {
      count += 1;
      const date = toIso(cursor);
      if (date >= start && date <= end) {
        occurrences.push({ id: `${task.id}::${date}`, sourceTaskId: task.id, date, task });
      }
      if (maxOccurrences && count >= maxOccurrences) {
        break;
      }
    }
    cursor.setDate(cursor.getDate() + 1);
  }

  return occurrences;
}

export type { TaskOccurrence };
