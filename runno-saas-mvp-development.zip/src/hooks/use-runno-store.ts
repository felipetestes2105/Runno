import { useEffect, useMemo, useState } from "react";
import { createInitialState, toDateInput } from "../lib/mock-data";
import type { AwaitingItem, DeadlineItem, EventItem, NoteItem, RunnoState, Space, TaskItem } from "../types";

const STORAGE_KEY = "runno-state-v1";

function readStore(userId: string): RunnoState {
  const raw = localStorage.getItem(`${STORAGE_KEY}:${userId}`);
  if (!raw) {
    return createInitialState(userId);
  }

  try {
    const parsed = JSON.parse(raw) as Partial<RunnoState>;
    return {
      spaces: parsed.spaces ?? [],
      tasks: parsed.tasks ?? [],
      events: parsed.events ?? [],
      awaiting: parsed.awaiting ?? [],
      deadlines: parsed.deadlines ?? [],
      notes: parsed.notes ?? [],
      currentSpaceId: parsed.currentSpaceId ?? null,
    };
  } catch {
    return createInitialState(userId);
  }
}

export function useRunnoStore(userId: string | null) {
  const [state, setState] = useState<RunnoState>({
    spaces: [],
    tasks: [],
    events: [],
    awaiting: [],
    deadlines: [],
    notes: [],
    currentSpaceId: null,
  });

  useEffect(() => {
    if (!userId) {
      setState({ spaces: [], tasks: [], events: [], awaiting: [], deadlines: [], notes: [], currentSpaceId: null });
      return;
    }

    setState(readStore(userId));
  }, [userId]);

  useEffect(() => {
    if (!userId) {
      return;
    }
    localStorage.setItem(`${STORAGE_KEY}:${userId}`, JSON.stringify(state));
  }, [state, userId]);

  const filteredTasks = useMemo(
    () => state.tasks.filter((task) => !state.currentSpaceId || task.spaceId === state.currentSpaceId),
    [state.tasks, state.currentSpaceId]
  );

  const filteredEvents = useMemo(
    () => state.events.filter((event) => !state.currentSpaceId || event.spaceId === state.currentSpaceId),
    [state.events, state.currentSpaceId]
  );

  const filteredAwaiting = useMemo(
    () => state.awaiting.filter((item) => !state.currentSpaceId || item.spaceId === state.currentSpaceId),
    [state.awaiting, state.currentSpaceId]
  );

  const filteredDeadlines = useMemo(
    () => state.deadlines.filter((item) => !state.currentSpaceId || item.spaceId === state.currentSpaceId),
    [state.deadlines, state.currentSpaceId]
  );

  const filteredNotes = useMemo(
    () => state.notes.filter((item) => !state.currentSpaceId || item.spaceId === state.currentSpaceId),
    [state.notes, state.currentSpaceId]
  );

  const setCurrentSpace = (spaceId: string) => {
    setState((previous) => ({ ...previous, currentSpaceId: spaceId }));
  };

  const createSpace = (space: Omit<Space, "id" | "createdAt" | "userId">) => {
    if (!userId) return;
    const nextSpace: Space = { id: crypto.randomUUID(), userId, createdAt: new Date().toISOString(), ...space };
    setState((previous) => ({
      ...previous,
      spaces: [...previous.spaces, nextSpace],
      currentSpaceId: previous.currentSpaceId ?? nextSpace.id,
    }));
  };

  const updateSpace = (spaceId: string, input: Partial<Space>) => {
    setState((previous) => ({
      ...previous,
      spaces: previous.spaces.map((space) => (space.id === spaceId ? { ...space, ...input } : space)),
    }));
  };

  const deleteSpace = (spaceId: string) => {
    setState((previous) => {
      const nextSpaces = previous.spaces.filter((space) => space.id !== spaceId);
      return {
        ...previous,
        spaces: nextSpaces,
        events: previous.events.filter((event) => event.spaceId !== spaceId),
        tasks: previous.tasks.filter((task) => task.spaceId !== spaceId),
        awaiting: previous.awaiting.filter((item) => item.spaceId !== spaceId),
        deadlines: previous.deadlines.filter((item) => item.spaceId !== spaceId),
        notes: previous.notes.filter((item) => item.spaceId !== spaceId),
        currentSpaceId: nextSpaces[0]?.id ?? null,
      };
    });
  };

  const createTask = (task: Omit<TaskItem, "id" | "userId" | "spaceId">) => {
    if (!userId || !state.currentSpaceId) return;
    const nextTask: TaskItem = { id: crypto.randomUUID(), userId, spaceId: state.currentSpaceId, ...task };
    setState((previous) => ({ ...previous, tasks: [nextTask, ...previous.tasks] }));
  };

  const updateTask = (taskId: string, input: Partial<TaskItem>) => {
    setState((previous) => ({
      ...previous,
      tasks: previous.tasks.map((task) => (task.id === taskId ? { ...task, ...input } : task)),
    }));
  };

  const deleteTask = (taskId: string) => {
    setState((previous) => ({ ...previous, tasks: previous.tasks.filter((task) => task.id !== taskId) }));
  };

  const toggleTaskStatus = (taskId: string) => {
    setState((previous) => ({
      ...previous,
      tasks: previous.tasks.map((task) =>
        task.id === taskId ? { ...task, status: task.status === "Pendente" ? "Concluida" : "Pendente" } : task
      ),
    }));
  };

  const deferTask = (taskId: string) => {
    setState((previous) => ({
      ...previous,
      tasks: previous.tasks.map((task) => {
        if (task.id !== taskId) return task;
        const nextDate = new Date(task.dueDate);
        nextDate.setDate(nextDate.getDate() + 1);
        return { ...task, dueDate: toDateInput(nextDate) };
      }),
    }));
  };

  const createEvent = (event: Omit<EventItem, "id" | "userId" | "spaceId">) => {
    if (!userId || !state.currentSpaceId) return;
    const nextEvent: EventItem = { id: crypto.randomUUID(), userId, spaceId: state.currentSpaceId, ...event };
    setState((previous) => ({ ...previous, events: [...previous.events, nextEvent] }));
  };

  const updateEvent = (eventId: string, input: Partial<EventItem>) => {
    setState((previous) => ({
      ...previous,
      events: previous.events.map((event) => (event.id === eventId ? { ...event, ...input } : event)),
    }));
  };

  const deleteEvent = (eventId: string) => {
    setState((previous) => ({ ...previous, events: previous.events.filter((event) => event.id !== eventId) }));
  };

  const createAwaiting = (input: Omit<AwaitingItem, "id" | "userId" | "spaceId" | "createdAt">) => {
    if (!userId || !state.currentSpaceId) return;
    const next: AwaitingItem = {
      id: crypto.randomUUID(),
      userId,
      spaceId: state.currentSpaceId,
      createdAt: new Date().toISOString(),
      ...input,
    };
    setState((previous) => ({ ...previous, awaiting: [next, ...previous.awaiting] }));
  };

  const updateAwaiting = (itemId: string, input: Partial<AwaitingItem>) => {
    setState((previous) => ({
      ...previous,
      awaiting: previous.awaiting.map((item) => (item.id === itemId ? { ...item, ...input } : item)),
    }));
  };

  const deleteAwaiting = (itemId: string) => {
    setState((previous) => ({ ...previous, awaiting: previous.awaiting.filter((item) => item.id !== itemId) }));
  };

  const createDeadline = (input: Omit<DeadlineItem, "id" | "userId" | "spaceId">) => {
    if (!userId || !state.currentSpaceId) return;
    const next: DeadlineItem = { id: crypto.randomUUID(), userId, spaceId: state.currentSpaceId, ...input };
    setState((previous) => ({ ...previous, deadlines: [...previous.deadlines, next] }));
  };

  const updateDeadline = (deadlineId: string, input: Partial<DeadlineItem>) => {
    setState((previous) => ({
      ...previous,
      deadlines: previous.deadlines.map((item) => (item.id === deadlineId ? { ...item, ...input } : item)),
    }));
  };

  const deleteDeadline = (deadlineId: string) => {
    setState((previous) => ({ ...previous, deadlines: previous.deadlines.filter((item) => item.id !== deadlineId) }));
  };

  const createNote = (input: Omit<NoteItem, "id" | "userId" | "spaceId" | "createdAt">) => {
    if (!userId || !state.currentSpaceId) return;
    const next: NoteItem = {
      id: crypto.randomUUID(),
      userId,
      spaceId: state.currentSpaceId,
      createdAt: new Date().toISOString(),
      ...input,
    };
    setState((previous) => ({ ...previous, notes: [next, ...previous.notes] }));
  };

  const updateNote = (noteId: string, input: Partial<NoteItem>) => {
    setState((previous) => ({
      ...previous,
      notes: previous.notes.map((note) => (note.id === noteId ? { ...note, ...input } : note)),
    }));
  };

  const deleteNote = (noteId: string) => {
    setState((previous) => ({ ...previous, notes: previous.notes.filter((note) => note.id !== noteId) }));
  };

  const replaceState = (next: RunnoState) => {
    setState(next);
  };

  return {
    ...state,
    filteredTasks,
    filteredEvents,
    filteredAwaiting,
    filteredDeadlines,
    filteredNotes,
    setCurrentSpace,
    createSpace,
    updateSpace,
    deleteSpace,
    createTask,
    updateTask,
    deleteTask,
    toggleTaskStatus,
    deferTask,
    createEvent,
    updateEvent,
    deleteEvent,
    createAwaiting,
    updateAwaiting,
    deleteAwaiting,
    createDeadline,
    updateDeadline,
    deleteDeadline,
    createNote,
    updateNote,
    deleteNote,
    replaceState,
  };
}
