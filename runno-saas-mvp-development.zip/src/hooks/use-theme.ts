import { useEffect, useState } from "react";
import type { ThemePreference } from "../types";

const THEME_STORAGE_KEY = "runno-theme-v1";

function detectSystemTheme() {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function getStoredTheme(): ThemePreference {
  const value = localStorage.getItem(THEME_STORAGE_KEY);
  if (value === "light" || value === "dark" || value === "system") {
    return value;
  }
  return "light";
}

export function useTheme() {
  const [themePreference, setThemePreference] = useState<ThemePreference>(() => getStoredTheme());

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");

    const applyTheme = () => {
      const resolvedTheme = themePreference === "system" ? detectSystemTheme() : themePreference;
      document.documentElement.setAttribute("data-theme", resolvedTheme);
      document.documentElement.style.colorScheme = resolvedTheme;
    };

    applyTheme();

    if (themePreference === "system") {
      const onChange = () => applyTheme();
      media.addEventListener("change", onChange);
      return () => media.removeEventListener("change", onChange);
    }

    return undefined;
  }, [themePreference]);

  useEffect(() => {
    localStorage.setItem(THEME_STORAGE_KEY, themePreference);
  }, [themePreference]);

  return { themePreference, setThemePreference };
}
