export type PageKey = "dashboard" | "calendar" | "tasks" | "notes" | "spaces" | "settings";
export type ThemePreference = "light" | "dark" | "system";

export type TaskPriority = "Critica" | "Importante" | "Normal";
export type TaskStatus = "Pendente" | "Concluida";
export type EventCategory = "Administrativo" | "Financeiro" | "RH" | "Compras" | "Pessoal";
export type RecurrenceType = "daily" | "weekly" | "monthly" | "yearly" | "custom";
export type RecurrenceEndType = "never" | "untilDate" | "occurrences";
export type CustomRecurrenceUnit = "days" | "weeks" | "months" | "years";

export interface TaskRecurrence {
  enabled: boolean;
  repeat: RecurrenceType;
  weeklyDays: number[];
  monthlyMode: "dayOfMonth" | "dayOfWeek";
  customInterval: number;
  customUnit: CustomRecurrenceUnit;
  endType: RecurrenceEndType;
  untilDate: string | null;
  occurrences: number | null;
}

export interface Profile {
  id: string;
  email: string;
  fullName: string;
}

export interface Space {
  id: string;
  userId: string;
  company: string;
  unit: string;
  createdAt: string;
}

export interface EventItem {
  id: string;
  userId: string;
  spaceId: string;
  title: string;
  description: string;
  date: string;
  time: string;
  category: EventCategory;
  color: string;
}

export interface TaskItem {
  id: string;
  userId: string;
  spaceId: string;
  title: string;
  description: string;
  category: EventCategory;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: string;
  time?: string;
  reminder?: string;
  deadline?: string;
  notesLinked?: string[];
  recurrence?: TaskRecurrence;
}

export interface AwaitingItem {
  id: string;
  userId: string;
  spaceId: string;
  title: string;
  description: string;
  status: "Aguardando" | "Concluido";
  createdAt: string;
}

export interface DeadlineItem {
  id: string;
  userId: string;
  spaceId: string;
  title: string;
  description: string;
  dueDate: string;
  time?: string;
  priority: TaskPriority;
  status: "EmAberto" | "Concluido";
  notesLinked?: string[];
}

export interface NoteItem {
  id: string;
  userId: string;
  spaceId: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  pinned: boolean;
  favorite: boolean;
  linkedType: "none" | "task" | "event" | "deadline" | "awaiting";
  linkedId: string | null;
  createdAt: string;
}

export interface RunnoState {
  spaces: Space[];
  events: EventItem[];
  tasks: TaskItem[];
  awaiting: AwaitingItem[];
  deadlines: DeadlineItem[];
  notes: NoteItem[];
  currentSpaceId: string | null;
}
