import type { EventCategory } from "../../types";

const categories: EventCategory[] = ["Administrativo", "Financeiro", "RH", "Compras", "Pessoal"];

export function CalendarLegend() {
  return (
    <div className="flex flex-wrap gap-2 text-xs text-zinc-400">
      {categories.map((category) => (
        <span key={category} className="rounded-full border border-zinc-700 px-3 py-1">
          {category}
        </span>
      ))}
    </div>
  );
}
