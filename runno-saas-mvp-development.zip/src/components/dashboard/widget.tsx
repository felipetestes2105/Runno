import type { ReactNode } from "react";

interface WidgetProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
}

export function Widget({ title, subtitle, children, className }: WidgetProps) {
  return (
    <section className={`rounded-3xl border border-zinc-800 bg-[#15151C]/85 p-5 backdrop-blur ${className ?? ""}`}>
      <header className="mb-4">
        <h3 className="text-sm font-medium text-zinc-200">{title}</h3>
        {subtitle && <p className="text-xs text-zinc-500">{subtitle}</p>}
      </header>
      {children}
    </section>
  );
}
