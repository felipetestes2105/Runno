import { motion } from "framer-motion";
import { CalendarDays, CheckSquare, ChevronLeft, ChevronRight, LayoutDashboard, LogOut, NotebookText, Search, Settings, Waypoints } from "lucide-react";
import { RunnoLogo } from "../ui/runno-logo";
import { cn } from "../../utils/cn";
import type { PageKey, Profile, Space } from "../../types";

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  activePage: PageKey;
  onPageChange: (page: PageKey) => void;
  profile: Profile;
  spaces: Space[];
  currentSpaceId: string | null;
  onSpaceChange: (id: string) => void;
  onOpenCommand: () => void;
  onLogout: () => void;
}

const items = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "calendar", label: "Calendario", icon: CalendarDays },
  { key: "tasks", label: "Tarefas", icon: CheckSquare },
  { key: "notes", label: "Anotacoes", icon: NotebookText },
  { key: "spaces", label: "Espacos", icon: Waypoints },
] as const;

export function Sidebar({
  collapsed,
  onToggle,
  activePage,
  onPageChange,
  profile,
  spaces,
  currentSpaceId,
  onSpaceChange,
  onOpenCommand,
  onLogout,
}: SidebarProps) {
  return (
    <motion.aside
      animate={{ width: collapsed ? 78 : 210 }}
      className="fixed left-0 top-0 z-30 h-screen border-r border-zinc-800 bg-[#0F0F14]/90 p-3 backdrop-blur"
    >
      <div className="flex h-full flex-col gap-4">
        <div className={cn("px-1", collapsed ? "space-y-2" : "flex items-center justify-between")}>
          <div className={cn("overflow-hidden transition-all", collapsed && "w-full")}>
            {!collapsed && (
              <>
                <RunnoLogo className="mb-0.5 scale-90 origin-left" />
              </>
            )}
            {collapsed && <RunnoLogo compact className="mx-auto scale-90" />}
          </div>
          <button
            className={cn(
              "rounded-xl border border-zinc-800 p-2 text-zinc-300 transition hover:bg-zinc-900 hover:text-zinc-100",
              collapsed && "mx-auto block"
            )}
            onClick={onToggle}
            aria-label={collapsed ? "Expandir menu" : "Recolher menu"}
          >
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {!collapsed && (
          <>
            <button
              onClick={onOpenCommand}
              className="flex h-10 items-center gap-2 rounded-xl border border-[var(--surface-border)] bg-[var(--surface-soft)] px-3 text-sm text-[var(--muted-text)]"
            >
              <Search size={14} /> Buscar
            </button>
            <select
              value={currentSpaceId ?? ""}
              onChange={(event) => onSpaceChange(event.target.value)}
              className="h-10 rounded-xl border border-[var(--surface-border)] bg-[var(--surface-soft)] px-3 text-sm text-[var(--app-text)] outline-none"
            >
              {spaces.map((space) => (
                <option key={space.id} value={space.id}>
                  {space.company} &gt; {space.unit}
                </option>
              ))}
            </select>
          </>
        )}

        <nav className="flex flex-col gap-2">
          {items.map((item) => {
            const Icon = item.icon;
            const active = activePage === item.key;
            return (
              <button
                key={item.key}
                className={cn(
                  "flex items-center gap-3 rounded-2xl px-3 py-3 text-sm transition",
                  collapsed && "justify-center px-2",
                  active
                    ? "sidebar-item-active bg-violet-500/20 text-violet-100"
                    : "text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100"
                )}
                onClick={() => onPageChange(item.key)}
              >
                <Icon size={18} />
                {!collapsed && <span>{item.label}</span>}
              </button>
            );
          })}
        </nav>

        <div className="mt-auto space-y-2">
          <button
            className={cn(
              "flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-sm transition text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100",
              collapsed && "justify-center px-2"
            )}
            onClick={() => onPageChange("settings")}
          >
            <Settings size={18} />
            {!collapsed && <span>Configuracoes</span>}
          </button>

          <button
            className={cn(
              "flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-sm transition text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100",
              collapsed && "justify-center px-2"
            )}
            onClick={onLogout}
          >
            <LogOut size={18} />
            {!collapsed && <span>Sair</span>}
          </button>

          {!collapsed && (
            <div className="rounded-2xl border border-[var(--surface-border)] bg-[var(--surface-soft)] px-3 py-2 text-sm text-[var(--muted-text)]">
              {profile.fullName}
            </div>
          )}
        </div>
      </div>
    </motion.aside>
  );
}
