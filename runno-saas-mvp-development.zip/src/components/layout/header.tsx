import { LogOut, Search } from "lucide-react";
import type { Profile, Space } from "../../types";

interface HeaderProps {
  profile: Profile;
  spaces: Space[];
  currentSpaceId: string | null;
  leftOffset: number;
  onSpaceChange: (id: string) => void;
  onOpenCommand: () => void;
  onLogout: () => void;
}

export function Header({
  profile,
  spaces,
  currentSpaceId,
  leftOffset,
  onSpaceChange,
  onOpenCommand,
  onLogout,
}: HeaderProps) {
  return (
    <header className="runno-header fixed right-0 top-0 z-40 h-20 backdrop-blur" style={{ left: leftOffset }}>
      <div className="flex h-full w-full items-center justify-between gap-4 px-6">

        <select
          value={currentSpaceId ?? ""}
          onChange={(event) => onSpaceChange(event.target.value)}
          className="h-11 min-w-56 rounded-2xl border border-[var(--surface-border)] bg-[var(--surface-soft)] px-3 text-sm text-[var(--app-text)] outline-none"
        >
          {spaces.map((space) => (
            <option key={space.id} value={space.id}>
              {space.company} &gt; {space.unit}
            </option>
          ))}
        </select>

        <button
          onClick={onOpenCommand}
          className="flex h-11 flex-1 items-center justify-between rounded-2xl border border-[var(--surface-border)] bg-[var(--surface-soft)] px-3 text-sm text-[var(--muted-text)] transition hover:text-[var(--app-text)]"
        >
          <span className="inline-flex items-center gap-2">
            <Search size={16} />
            Buscar tarefas, eventos e espacos...
          </span>
          <span className="rounded-lg border border-zinc-700 px-2 py-1 text-xs">Ctrl K</span>
        </button>

        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-violet-500/20 text-sm font-semibold text-violet-200">
            {profile.fullName.slice(0, 2).toUpperCase()}
          </div>
          <button
            onClick={onLogout}
            className="rounded-xl border border-[var(--surface-border)] p-2 text-[var(--muted-text)] transition hover:bg-[var(--surface-soft)] hover:text-[var(--app-text)]"
            title="Sair"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  );
}
