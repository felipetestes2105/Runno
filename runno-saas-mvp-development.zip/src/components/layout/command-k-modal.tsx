import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Modal } from "../ui/modal";
import { taskPriorityColor } from "../../lib/task-priority";
import type { TaskPriority, TaskStatus } from "../../types";

interface CommandItem {
  id: string;
  type: string;
  title: string;
  description: string;
  priority?: TaskPriority;
  status?: TaskStatus;
}

interface CommandKModalProps {
  open: boolean;
  onClose: () => void;
  items: CommandItem[];
}

export function CommandKModal({ open, onClose, items }: CommandKModalProps) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query) return items.slice(0, 8);
    const normalized = query.toLowerCase();
    return items
      .filter((item) => `${item.title} ${item.description}`.toLowerCase().includes(normalized))
      .slice(0, 8);
  }, [query, items]);

  return (
    <Modal open={open} onClose={onClose}>
      <div className="space-y-4">
        <div className="inline-flex items-center gap-2 text-zinc-300">
          <Search size={16} />
          <p className="text-sm">Busca global do Runno</p>
        </div>

        <input
          autoFocus
          placeholder="Digite para buscar..."
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          className="h-11 w-full rounded-2xl border border-zinc-700 bg-zinc-950 px-3 text-sm outline-none ring-violet-500 focus:ring-2"
        />

        <div className="space-y-2">
          {filtered.map((item) => (
            <button
              key={item.id}
              className="w-full rounded-2xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-left transition hover:border-zinc-600"
              style={
                item.type === "Tarefa" && item.priority
                  ? { boxShadow: `inset 3px 0 0 ${taskPriorityColor(item.priority)}` }
                  : undefined
              }
              onClick={onClose}
            >
              <p className="text-sm text-zinc-100">
                {item.type === "Tarefa" && item.status === "Concluida" ? "✓ " : item.type === "Tarefa" ? "○ " : ""}
                {item.title}
              </p>
              <p className="text-xs text-zinc-500">
                {item.type} - {item.description}
              </p>
            </button>
          ))}
          {filtered.length === 0 && <p className="text-sm text-zinc-500">Nenhum resultado encontrado.</p>}
        </div>
      </div>
    </Modal>
  );
}
