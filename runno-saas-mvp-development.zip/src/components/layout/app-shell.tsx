import { useState, type ReactNode } from "react";
import type { PageKey, Profile, Space } from "../../types";
import { Sidebar } from "./sidebar";

interface AppShellProps {
  profile: Profile;
  activePage: PageKey;
  onPageChange: (page: PageKey) => void;
  spaces: Space[];
  currentSpaceId: string | null;
  onSpaceChange: (id: string) => void;
  onOpenCommand: () => void;
  onLogout: () => void;
  mainClassName?: string;
  children: ReactNode;
}

export function AppShell({
  profile,
  activePage,
  onPageChange,
  spaces,
  currentSpaceId,
  onSpaceChange,
  onOpenCommand,
  onLogout,
  mainClassName,
  children,
}: AppShellProps) {
  const [collapsed, setCollapsed] = useState(false);
  const sidebarWidth = collapsed ? "ml-[78px]" : "ml-[210px]";

  return (
    <div className="min-h-screen bg-[#0B0B0F] text-zinc-100">
      <Sidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed((previous) => !previous)}
        activePage={activePage}
        onPageChange={onPageChange}
        profile={profile}
        spaces={spaces}
        currentSpaceId={currentSpaceId}
        onSpaceChange={onSpaceChange}
        onOpenCommand={onOpenCommand}
        onLogout={onLogout}
      />

      <div className={`${sidebarWidth} transition-all duration-300`}>
        <main className={mainClassName ?? "mx-auto max-w-[1400px] px-6 pb-8 pt-6"}>{children}</main>
      </div>
    </div>
  );
}
