interface SpaceBreadcrumbProps {
  company: string;
  unit: string;
}

export function SpaceBreadcrumb({ company, unit }: SpaceBreadcrumbProps) {
  return (
    <p className="text-sm text-zinc-300">
      {company} <span className="text-zinc-600">&gt;</span> {unit}
    </p>
  );
}
