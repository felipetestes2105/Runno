import type { InputHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-2xl border border-[var(--surface-border)] bg-[var(--surface-soft)] px-3 text-sm text-[var(--app-text)] outline-none ring-violet-500 transition focus:ring-2",
        className
      )}
      {...props}
    />
  );
}
