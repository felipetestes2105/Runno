import type { ButtonHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger";
}

export function Button({ className, variant = "primary", ...props }: ButtonProps) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 disabled:cursor-not-allowed disabled:opacity-50",
        variant === "primary" && "bg-violet-500 text-white hover:bg-violet-400",
        variant === "secondary" && "border border-[var(--surface-border)] bg-[var(--surface-soft)] text-[var(--app-text)] hover:bg-zinc-800/70",
        variant === "ghost" && "text-[var(--muted-text)] hover:bg-[var(--surface-soft)]",
        variant === "danger" && "bg-red-500/80 text-white hover:bg-red-500",
        className
      )}
      {...props}
    />
  );
}
