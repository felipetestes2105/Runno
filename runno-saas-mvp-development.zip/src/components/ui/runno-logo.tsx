import { cn } from "../../utils/cn";

interface RunnoLogoProps {
  compact?: boolean;
  className?: string;
}

export function RunnoLogo({ compact = false, className }: RunnoLogoProps) {
  return (
    <div className={cn("inline-flex items-center gap-3", className)}>
      <div className="runno-logo-mark relative grid h-10 w-10 place-items-center rounded-2xl border border-violet-400/25 bg-violet-500/15 text-violet-200 shadow-[0_0_24px_rgba(139,92,246,0.35)]">
        <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" aria-hidden="true">
          <path
            d="M6 18V6h6.5a3.5 3.5 0 1 1 0 7H9.5"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path d="M9.5 13c3.2 0 5.5 2 6.5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          <circle cx="18.5" cy="5.5" r="1.5" fill="currentColor" className="opacity-80" />
        </svg>
      </div>

      {!compact && (
        <div className="relative">
          <p className="runno-logo-text bg-gradient-to-r from-zinc-100 via-violet-200 to-violet-400 bg-clip-text text-xl font-semibold tracking-[0.2em] text-transparent">
            RUNNO
          </p>
        </div>
      )}
    </div>
  );
}
