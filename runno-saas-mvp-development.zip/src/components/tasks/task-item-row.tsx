import type { DragEvent } from "react";
import { ArrowDown, ArrowUp, CheckCircle2, GripVertical, Pencil, RotateCcw, Trash2 } from "lucide-react";
import { formatDateBR } from "../../lib/date-format";
import { taskPriorityColor } from "../../lib/task-priority";
import type { TaskItem } from "../../types";

interface TaskItemRowProps {
  task: TaskItem;
  onToggle?: (taskId: string) => void;
  onEdit?: (task: TaskItem) => void;
  onDelete?: (taskId: string) => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  draggable?: boolean;
  onDragStart?: (event: DragEvent<HTMLDivElement>) => void;
  onDragOver?: (event: DragEvent<HTMLDivElement>) => void;
  onDrop?: (event: DragEvent<HTMLDivElement>) => void;
}

export function TaskItemRow({
  task,
  onToggle,
  onEdit,
  onDelete,
  onMoveUp,
  onMoveDown,
  draggable,
  onDragStart,
  onDragOver,
  onDrop,
}: TaskItemRowProps) {
  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      className={`rounded-2xl border border-zinc-800 p-3 ${
        task.status === "Concluida" ? "bg-zinc-950/25 opacity-85" : "bg-zinc-950/40"
      }`}
      style={{ boxShadow: `inset 3px 0 0 ${taskPriorityColor(task.priority)}` }}
    >
      <div className="flex items-start gap-2">
        <button
          className={`grid h-8 w-8 place-items-center text-xl leading-none ${task.status === "Concluida" ? "text-emerald-300" : "text-zinc-200"}`}
          onClick={() => onToggle?.(task.id)}
          title={task.status === "Concluida" ? "Reabrir tarefa" : "Concluir tarefa"}
        >
          {task.status === "Concluida" ? "✓" : "○"}
        </button>

        <div className="min-w-0 flex-1">
          <p className={`truncate text-sm ${task.status === "Concluida" ? "text-zinc-500 line-through" : "text-zinc-100"}`}>{task.title}</p>
          <p className="text-xs text-zinc-500">
            {task.priority} | {formatDateBR(task.dueDate)}
            {task.recurrence?.enabled && <span className="ml-2 rounded-md border border-zinc-700 px-1.5 py-0.5">Recorrente</span>}
          </p>
        </div>

        <div className="flex items-center gap-1">
          {draggable && <GripVertical size={14} className="text-zinc-500" />}
          {onMoveUp && (
            <button className="rounded-md p-1 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100" onClick={onMoveUp} title="Mover para cima">
              <ArrowUp size={14} />
            </button>
          )}
          {onMoveDown && (
            <button className="rounded-md p-1 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100" onClick={onMoveDown} title="Mover para baixo">
              <ArrowDown size={14} />
            </button>
          )}
          {onEdit && (
            <button className="rounded-md p-1 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100" onClick={() => onEdit(task)} title="Editar">
              <Pencil size={14} />
            </button>
          )}
          {onToggle && (
            <button
              className="rounded-md p-1 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100"
              onClick={() => onToggle(task.id)}
              title={task.status === "Concluida" ? "Reabrir" : "Concluir"}
            >
              {task.status === "Concluida" ? <RotateCcw size={14} /> : <CheckCircle2 size={14} />}
            </button>
          )}
          {onDelete && (
            <button className="rounded-md p-1 text-zinc-400 hover:bg-zinc-900 hover:text-red-300" onClick={() => onDelete(task.id)} title="Excluir">
              <Trash2 size={14} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
