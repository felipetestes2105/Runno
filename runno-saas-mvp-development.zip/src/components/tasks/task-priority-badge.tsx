import { cn } from "../../utils/cn";
import type { TaskPriority } from "../../types";

interface TaskPriorityBadgeProps {
  priority: TaskPriority;
}

export function TaskPriorityBadge({ priority }: TaskPriorityBadgeProps) {
  return (
    <span
      className={cn(
        "rounded-full px-2 py-1 text-xs",
        priority === "Critica" && "bg-red-500/20 text-red-200",
        priority === "Importante" && "bg-amber-500/20 text-amber-200",
        priority === "Normal" && "bg-zinc-500/20 text-zinc-200"
      )}
    >
      {priority}
    </span>
  );
}
