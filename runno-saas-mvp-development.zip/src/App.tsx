import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AuthPage } from "./app/auth-page";
import { CalendarPage } from "./app/calendar-page";
import { DashboardPage } from "./app/dashboard-page";
import { NotesPage } from "./app/notes-page";
import { SettingsPage } from "./app/settings-page";
import { SpacesPage } from "./app/spaces-page";
import { TasksPage } from "./app/tasks-page";
import { AppShell } from "./components/layout/app-shell";
import { CommandKModal } from "./components/layout/command-k-modal";
import { useCommandK } from "./hooks/use-command-k";
import { useRunnoStore } from "./hooks/use-runno-store";
import { useTheme } from "./hooks/use-theme";
import type { PageKey, Profile } from "./types";

const AUTH_STORAGE_KEY = "runno-auth-v1";

function getStoredProfile() {
  const value = localStorage.getItem(AUTH_STORAGE_KEY);
  if (!value) {
    return null;
  }

  try {
    return JSON.parse(value) as Profile;
  } catch {
    return null;
  }
}

export default function App() {
  const [activePage, setActivePage] = useState<PageKey>("dashboard");
  const [profile, setProfile] = useState<Profile | null>(() => getStoredProfile());
  const [commandOpen, setCommandOpen] = useState(false);
  const [calendarFocus] = useState<{ date: string; mode: "events" | "agenda"; token: number } | null>(null);
  const { themePreference, setThemePreference } = useTheme();

  const store = useRunnoStore(profile?.id ?? null);

  useCommandK(() => setCommandOpen(true));

  const searchItems = useMemo(
    () => [
      ...store.tasks.map((task) => ({
        id: task.id,
        type: "Tarefa",
        title: task.title,
        description: task.description,
        priority: task.priority,
        status: task.status,
      })),
      ...store.events.map((event) => ({
        id: event.id,
        type: "Evento",
        title: event.title,
        description: event.description,
      })),
      ...store.spaces.map((space) => ({
        id: space.id,
        type: "Espaco",
        title: `${space.company} > ${space.unit}`,
        description: "Espaco ativo",
      })),
      ...store.notes.map((note) => ({
        id: note.id,
        type: "Anotacao",
        title: note.title,
        description: note.content,
      })),
      ...store.deadlines.map((deadline) => ({
        id: deadline.id,
        type: "Prazo",
        title: deadline.title,
        description: deadline.description,
      })),
    ],
    [store.tasks, store.events, store.spaces, store.notes, store.deadlines]
  );

  const handleAuth = (nextProfile: Profile) => {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(nextProfile));
    setProfile(nextProfile);
  };

  const handleLogout = () => {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    setProfile(null);
  };

  if (!profile) {
    return <AuthPage onAuth={handleAuth} />;
  }

  return (
    <>
      <AppShell
        profile={profile}
        activePage={activePage}
        onPageChange={setActivePage}
        spaces={store.spaces}
        currentSpaceId={store.currentSpaceId}
        onSpaceChange={store.setCurrentSpace}
        onOpenCommand={() => setCommandOpen(true)}
        onLogout={handleLogout}
        mainClassName={
          activePage === "calendar" || activePage === "dashboard"
            ? "w-full max-w-none px-3 pb-5 pt-4"
            : "mx-auto max-w-[1400px] px-6 pb-8 pt-4"
        }
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="min-h-[calc(100vh-7rem)]"
          >
            {activePage === "dashboard" && (
              <DashboardPage
                tasks={store.filteredTasks}
                events={store.filteredEvents}
                awaiting={store.filteredAwaiting}
                deadlines={store.filteredDeadlines}
                notes={store.filteredNotes}
                onCreateTask={store.createTask}
                onUpdateTask={store.updateTask}
                onDeleteTask={store.deleteTask}
                onToggleTask={store.toggleTaskStatus}
                onCreateAwaiting={store.createAwaiting}
                onUpdateAwaiting={store.updateAwaiting}
                onDeleteAwaiting={store.deleteAwaiting}
                onCreateDeadline={store.createDeadline}
                onUpdateDeadline={store.updateDeadline}
                onDeleteDeadline={store.deleteDeadline}
                onCreateNote={store.createNote}
                onUpdateNote={store.updateNote}
                onDeleteNote={store.deleteNote}
                onUpdateEvent={store.updateEvent}
                onDeleteEvent={store.deleteEvent}
                onOpenCalendar={() => setActivePage("calendar")}
              />
            )}
            {activePage === "calendar" && (
              <CalendarPage
                events={store.filteredEvents}
                tasks={store.filteredTasks}
                notes={store.filteredNotes}
                deadlines={store.filteredDeadlines}
                onCreateEvent={store.createEvent}
                onUpdateEvent={store.updateEvent}
                onDeleteEvent={store.deleteEvent}
                onCreateTask={store.createTask}
                onToggleTask={store.toggleTaskStatus}
                onUpdateTask={store.updateTask}
                focusDate={calendarFocus?.date}
                focusMode={calendarFocus?.mode}
                focusToken={calendarFocus?.token}
              />
            )}
            {activePage === "tasks" && (
              <TasksPage
                tasks={store.filteredTasks}
                notes={store.filteredNotes}
                onCreateTask={store.createTask}
                onUpdateTask={store.updateTask}
                onDeleteTask={store.deleteTask}
                onToggleTask={store.toggleTaskStatus}
              />
            )}
            {activePage === "notes" && (
              <NotesPage
                notes={store.filteredNotes}
                tasks={store.filteredTasks}
                events={store.filteredEvents}
                deadlines={store.filteredDeadlines}
                awaiting={store.filteredAwaiting}
                onCreateNote={store.createNote}
                onUpdateNote={store.updateNote}
                onDeleteNote={store.deleteNote}
              />
            )}
            {activePage === "spaces" && (
              <SpacesPage
                spaces={store.spaces}
                currentSpaceId={store.currentSpaceId}
                onCreateSpace={store.createSpace}
                onUpdateSpace={store.updateSpace}
                onDeleteSpace={store.deleteSpace}
                onSelectSpace={store.setCurrentSpace}
              />
            )}
            {activePage === "settings" && (
              <SettingsPage
                profile={profile}
                spaces={store.spaces}
                themePreference={themePreference}
                onThemeChange={setThemePreference}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </AppShell>

      <CommandKModal open={commandOpen} onClose={() => setCommandOpen(false)} items={searchItems} />
    </>
  );
}
